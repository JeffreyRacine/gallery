# Fresh nuisance comparison: bounded plan, 12 October 2026

Jeffrey authorized a BFGS attempt for reference code 10 and comparison of fresh
`np` propensity estimators and kernels. Reasonable quantitative and qualitative
agreement is sufficient for a useful example; exact equality is not required.

## Order and fixed scope

1. Verify the 1,084-row author sample and saved propensity ordering. There are
   three distinct covariate designs: the first two outcomes share one design.
2. Change only the corrected reference propensity bandwidth optimizer from
   Nelder–Mead to BFGS in a separate source copy. Keep Epanechnikov, the inner
   local multinomial likelihood, start (0.8,0.8), tolerances and iteration limit.
   Run the three designs, keeping all convergence codes and objective values.
3. Fit three `np` propensity approaches with both second-order kernels:
   - LC regression of the four indicators, with common weights and two shared
     bandwidths. Minimize joint leave-one-out Brier loss.
   - LC conditional probabilities from `npconmode`, using `npcdensbw` CVML and
     separately selected bandwidths for each predictor and the class response.
   - Local-linear `npconmode` with its explicit proper-probability projection,
     using `npcdensbw` CVLS and separately selected bandwidths.
   Native conditional selectors use two starts and a fixed seed. The shared
   selector uses two declared starts (halfwidth 0.8, lambda 0.8) and (0.35,0.25),
   Nelder–Mead on log(h) and logit(lambda), maxit 250, reltol 1e-7. No candidate
   is fitted to the author's propensity arrays or to a target ATT.
4. Compare all raw and author-style floored probabilities with the saved
   author arrays: overall and cell-specific RMSE, observed-class log loss,
   row sums, minima, and weighting diagnostics. Rank families by mean propensity
   RMSE over the three distinct designs, retaining every candidate. Exact
   delete-one class probabilities are evaluated with bandwidths held fixed.
5. Re-estimate the outcome regressions in `np`: local-linear, two bandwidths
   shared across all four groups, pooled leave-one-out squared error divided by
   n. Same two starts, optimizer and limits as the shared propensity fit.
   Evaluate own-group means leave-one-out and counterfactual means at treated
   post observations. Use Gaussian and Epanechnikov (eight outcome fits).
6. Report both stage isolation (fresh propensities plus previously retained
   published-bandwidth `np` outcome fits) and the fully fresh nuisance table.
   Pair kernels for the main comparisons, and report every predeclared family.
   Preserve the author's propensity clipping to [0.01,0.99], without subsequent renormalizing;
   save raw arrays separately. Use the same normalized ATT score and clustered
   multiplier inference as the checked earlier example (131 clusters, 9,999
   Mammen draws, seed 1234). Include the author results as a comparator only.
7. Verify the selected computation with literal LC kernel sums and delete-one
   API checks, verify independent score calculations, retain failures and
   receipts, and produce a readable report and runnable example.

## Numerical and execution boundaries

The shared continuous parameter is expressed as an Epanechnikov halfwidth;
both kernels receive public `np` bandwidth h/sqrt(5), matching their variances.
The categorical kernel is Li–Racine. Undefined candidate objective evaluations
are recorded as infeasible with a large penalty; failed fits are never replaced
silently. A final candidate must have a finite objective, a successful optimizer
status and all required predictions. Native conditional searches keep their
existing defaults except the declared controls. No production package edits.

Each fit has a 30-minute external cap and no automatic retry. At most four
single-threaded, nice-20 workers run on each remote host. M2Studio coordinates
and analyzes, reserving capacity for the concurrent release work. For the user's
absolute workspace boundary, this campaign explicitly uses the same absolute
path under `/Users/jracine/Development` on M2MBP and pc-racine1, not remote
`/Users/scratch`. All temporary/compiler files stay beneath this campaign.
Reuse the unchanged, tarball-installed private np 0.80-1 / corrected compdid
0.1.0 libraries from the preceding published-comparison study; retain the same
tarballs. Freeze source hashes before launch, retain exit receipts and check
that all owned processes have ended. Preserve all earlier studies verbatim.

This is an exploratory same-data reimplementation, not independent evidence
that any new nuisance choice satisfies all of the paper's inference conditions.
Closeness is descriptive and the search is bounded to the candidates above.
