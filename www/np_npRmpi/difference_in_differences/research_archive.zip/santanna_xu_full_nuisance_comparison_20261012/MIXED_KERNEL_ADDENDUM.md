# One bounded follow-through specification

Recorded after the 18 np propensity attempts and eight outcome attempts, before
computing the mixed-kernel ATT. Among complete np propensity families, shared
Epanechnikov LC has the lowest mean RMSE against the archived propensities:
0.14537 across the three designs. This is descriptive closeness, not exact
agreement. Paired Epanechnikov outcomes fail for shipment value because eleven
required external predictions have zero kernel weights; all Gaussian outcome
fits complete.

Following Jeffrey's instruction to carry the closest propensity approach into
the main table, evaluate **Epanechnikov LC propensities with Gaussian
local-linear outcomes for all four outcomes**. This is one additional explicit
specification, using already fitted arrays, with no new search or retries.
Retain all original paired-kernel specifications, the failed prediction, and
the new specification's complete four-outcome results regardless of closeness.
It is not a row-specific fallback. Both nuisance stages and bandwidths were
estimated freshly from the data; the only reference-based choice is selecting
the propensity family by the previously declared descriptive RMSE ranking.
