# Run from this study directory. Default: recompute the table from retained fits.
# --refit: fresh Gaussian LC npconmode propensities and shared-bandwidth LL np
# outcomes, saving new records separately. The saved author nuisances are used
# only for the comparison column, never in either freshly fitted nuisance stage.
refit<-'--refit' %in% commandArgs(TRUE)
if(refit) {
 source('R/fit.R')
 outarg<-grep('^--out=',commandArgs(TRUE),value=TRUE)
 dest<-if(length(outarg))sub('^--out=','',outarg[1]) else 'results/example_refit'
 if(dir.exists(dest))stop('Refit output exists; preserve it and choose a fresh output with --out=results/name')
 dir.create(dest)
 props<-list();records<-list()
 for(i in 1:4) {
  design<-if(i==2L)1L else i
  a<-new.env(parent=emptyenv());a$evaluations<-list();a$warnings<-character()
  if(is.null(props[[as.character(design)]]))props[[as.character(design)]]<-fit_ps_conmode(design,'gaussian','lc',a)
  b<-new.env(parent=emptyenv());b$evaluations<-list();b$warnings<-character()
  or<-fit_or(i,'gaussian',b)
  ps<-props[[as.character(design)]]$raw
  s<-sx_score(dat[[ref$locpol$ynames[i]]],d,post,clip_ps(ps),or$mu)
  records[[i]]<-list(propensity=props[[as.character(design)]],outcome=or,score=s,ps_audit=as.list(a),or_audit=as.list(b))
  saveRDS(records[[i]],sprintf('%s/%d.rds',dest,i))
 }
 source('R/data.R')
} else {
 source('R/data.R')
 jobs<-read.csv('inputs/jobs.csv');records<-vector('list',4)
 for(i in 1:4) {
  design<-if(i==2L)1L else i
  pid<-jobs$id[jobs$kind=='ps_conmode_lc' & jobs$i==design & jobs$kernel=='gaussian']
  oid<-jobs$id[jobs$kind=='outcome' & jobs$i==i & jobs$kernel=='gaussian']
  p<-readRDS(sprintf('results/fits/%02d.rds',pid));o<-readRDS(sprintf('results/fits/%02d.rds',oid))
  stopifnot(p$ok,o$ok)
  records[[i]]<-list(score=sx_score(dat[[ref$locpol$ynames[i]]],d,post,pmin(pmax(p$fit$raw,.01),.99),o$fit$mu))
 }
}
g<-as.integer(factor(cluster));G<-max(g);n<-nrow(dat);B<-ref$locpol$nboot
set.seed(ref$locpol$seed);table<-list()
for(i in 1:4) {
 lo<-(1-sqrt(5))/2;hi<-(1+sqrt(5))/2
 M<-matrix(ifelse(rbinom(G*B,1,hi/sqrt(5))==1,lo,hi),G,B)
 s<-records[[i]]$score;v<-drop(crossprod(drop(rowsum(s$influence,g,reorder=TRUE)),M))/n
 se<-IQR(v)/(qnorm(.75)-qnorm(.25))
 paper<-ref$table4[ref$table4$outcome==ref$table4$outcome[i] & grepl('tau_dr',ref$table4$estimator),]
 table[[i]]<-data.frame(outcome=ref$locpol$ynames[i],paper_ATT=paper$estimate,np_ATT=s$att,np_cluster_se=se)
}
table<-do.call(rbind,table);print(table,row.names=FALSE)
if(!refit) {
 expected<-read.csv('results/main_results.csv');expected<-expected[expected$kind=='ps_conmode_lc' & expected$kernel=='gaussian' & expected$stage=='fresh_outcomes',]
 stopifnot(max(abs(table$np_ATT-expected$ATT))<1e-10,max(abs(table$np_cluster_se-expected$cluster_se))<1e-10)
 cat('RETAINED_EXAMPLE_PASS\n')
} else {
 write.csv(table,file.path(dest,'table.csv'),row.names=FALSE)
 expected<-read.csv('results/main_results.csv');expected<-expected[expected$kind=='ps_conmode_lc' & expected$kernel=='gaussian' & expected$stage=='fresh_outcomes',]
 difference<-max(abs(table$np_ATT-expected$ATT),abs(table$np_cluster_se-expected$cluster_se))
 writeLines(sprintf('Maximum ATT/SE difference from retained run: %.17g',difference),file.path(dest,'agreement.txt'))
 stopifnot(difference<1e-8)
 cat('FRESH_EXAMPLE_PASS\n')
}
