source('R/load.R')
stopifnot(identical(make_x(1),make_x(2)),
 identical(ref$locpol$ps_fit[[1]]$fitted.values,ref$locpol$ps_fit[[2]]$fitted.values))
clip_ps<-function(p)pmin(pmax(p,.01),.99)
shared_bw<-function(x,y,theta,kernel,type) {
 npregbw(xdat=x,ydat=y,bws=c(rep(theta[1]/sqrt(5),2),rep(theta[2],9)),
   bandwidth.compute=FALSE,regtype=type,ckertype=kernel,ukertype='liracine')
}
shared_search<-function(fun,audit) {
 # Optimize valid positive continuous bandwidths and interior categorical ones.
 decode<-function(z)c(exp(z[1]),plogis(z[2]))
 objective<-function(z) {
  theta<-decode(z);err<-''
  val<-tryCatch(fun(theta),error=function(e){err<<-conditionMessage(e);NA_real_})
  feasible<-length(val)==1L && is.finite(val)
  audit$evaluations[[length(audit$evaluations)+1L]]<-list(theta=theta,value=val,feasible=feasible,error=err)
  if(length(audit$evaluations)%%25L==0L)message('CV evaluations ',length(audit$evaluations),' value ',val)
  if(feasible)val else 1e8
 }
 starts<-list(c(.8,.8),c(.35,.25))
 runs<-lapply(starts,function(s)optim(c(log(s[1]),qlogis(s[2])),objective,
   method='Nelder-Mead',control=list(maxit=250,reltol=1e-7)))
 audit$searches<-runs
 eligible<-vapply(runs,function(r)r$convergence==0L && is.finite(r$value) && r$value<1e8,logical(1))
 if(!any(eligible))stop('No converged finite shared-bandwidth search')
 j<-which(eligible)[which.min(vapply(runs[eligible],`[[`,numeric(1),'value'))]
 list(theta=decode(runs[[j]]$par),value=runs[[j]]$value,selected_start=j,convergence=runs[[j]]$convergence)
}
fit_ps_lc<-function(i,kernel,audit) {
 x<-make_x(i)
 getp<-function(theta) {
  b<-shared_bw(x,cells[,1],theta,kernel,'lc')
  p<-as.matrix(npreghat(bws=b,txdat=x,y=cells,leave.one.out=TRUE,output='apply'))
  stopifnot(all(is.finite(p)),min(p)>-1e-12,max(abs(rowSums(p)-1))<1e-10)
  p
 }
 audit$stage<-'shared propensity CV'
 s<-shared_search(function(theta)mean(rowSums((cells-getp(theta))^2)),audit)
 audit$selected<-s;audit$stage<-'propensity evaluation'
 list(raw=getp(s$theta),bws=shared_bw(x,cells[,1],s$theta,kernel,'lc'),selection=s)
}
fit_ps_conmode<-function(i,kernel,type,audit) {
 x<-make_x(i);y<-factor(max.col(cells),levels=1:4,labels=c('11','10','01','00'))
 seed<-852000L+100L*i+if(type=='ll')10L else 0L
 set.seed(seed);audit$stage<-'native conditional bandwidth CV';message(audit$stage)
 b<-npcdensbw(xdat=x,ydat=y,regtype=type,
   bwmethod=if(type=='lc')'cv.ml' else 'cv.ls',
   cxkertype=kernel,uxkertype='liracine',uykertype='aitchisonaitken',nmulti=2L)
 audit$bws<-b;audit$seed<-seed;audit$stage<-'delete-one conditional probabilities'
 p<-matrix(NA_real_,nrow(x),4,dimnames=list(NULL,levels(y)))
 for(j in seq_len(nrow(x))) {
  f<-npconmode(bws=b,txdat=x[-j,,drop=FALSE],tydat=y[-j],exdat=x[j,,drop=FALSE],
    probabilities=TRUE,proper=type!='lc',se=FALSE)
  pr<-predict(f,type='prob')
  stopifnot(setequal(colnames(pr),levels(y)))
  p[j,]<-pr[,levels(y)]
  if(j%%100L==0L)message('LOO probabilities ',j,'/',nrow(x))
 }
 stopifnot(all(is.finite(p)),min(p)>-1e-12,max(abs(rowSums(p)-1))<1e-10)
 list(raw=p,bws=b,seed=seed)
}
fit_or<-function(i,kernel,audit) {
 x<-make_x(i);y<-dat[[ref$locpol$ynames[i]]]
 train<-lapply(1:4,function(g)which(cells[,g]==1))
 loo_fit<-function(theta,return_fit=FALSE) {
  predictions<-numeric(length(y));fits<-vector('list',4)
  for(g in 1:4) {
   tr<-train[[g]];b<-shared_bw(x[tr,,drop=FALSE],y[tr],theta,kernel,'ll')
   predictions[tr]<-as.numeric(npreghat(bws=b,txdat=x[tr,,drop=FALSE],y=y[tr],
     leave.one.out=TRUE,output='apply'))
   fits[[g]]<-b
  }
  stopifnot(all(is.finite(predictions)))
  if(return_fit)list(loo=predictions,bws=fits) else mean((y-predictions)^2)
 }
 audit$stage<-'pooled outcome CV'
 s<-shared_search(loo_fit,audit);audit$selected<-s
 f<-loo_fit(s$theta,TRUE);audit$bws<-f$bws
 mu<-matrix(NA_real_,nrow(x),4);mu[,1]<-0;te<-train[[1]]
 for(g in 2:4) {
  audit$stage<-paste('required outcome prediction',g);message(audit$stage)
  tr<-train[[g]];mu[tr,g]<-f$loo[tr]
  mu[te,g]<-as.numeric(fitted(npreg(bws=f$bws[[g]],txdat=x[tr,,drop=FALSE],tydat=y[tr],
    exdat=x[te,,drop=FALSE],se=FALSE)))
  stopifnot(all(is.finite(mu[c(tr,te),g])))
 }
 list(mu=mu,bws=f$bws,selection=s,loo=f$loo)
}
fit_reference<-function(i,audit) {
 audit$stage<-'load isolated BFGS reference'
 env<-new.env()
 Rcpp::sourceCpp('src/reference_bfgs.cpp',env=env,cacheDir='tmp/reference_cache',rebuild=FALSE,showOutput=FALSE)
 x<-make_x(i);cov<-cbind(as.matrix(x[,1:2]),as.matrix(dat[,ref$locpol$xunames]))
 dims<-c(2,9,0)
 audit$stage<-'BFGS propensity CV';message(audit$stage)
 b<-env$paper_cv_ps(cells,cov,dims,'cv.ml','logit',1L,matrix(c(.8,.8),2))
 audit$bws<-b;print(b)
 audit$stage<-'BFGS propensity evaluation'
 p<-env$paper_locpolfit_ps(as.numeric(b$bw_cv),cells,cov,dims,'logit')
 stopifnot(all(is.finite(p)))
 list(raw=p,bws=b,outer_converged=b$convergence==0 && b$value<1e8)
}
