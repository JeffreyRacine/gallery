# Robustness check using np: the tariff-evasion application

This example revisits Sant’Anna–Xu’s application with the same data and analogous
`np` functions. Both nuisance stages and their bandwidths are freshly estimated.
The main Gaussian LC `npconmode` / local-linear `npreg` specification is in broad
agreement with the published results: all four effect directions agree and three
point estimates are within about half a published clustered standard error.
The shipment-value effect is smaller and log bribes lose 5% significance.

The [report](REPORT.md) and [rendered report](report.html) present this as a
same-data robustness check. A method comparison explains the class-probability
estimator, bandwidth selection and kernel choices. Supporting sensitivity
results retain every candidate and failure from the bounded comparison.

The [plan](PLAN.md) fixes the original 29 fitting attempts. The
[mixed-kernel addendum](MIXED_KERNEL_ADDENDUM.md) adds one score-only combination
after selecting the closest propensity family.

`R/fit.R` contains the fresh nuisance fits. `example.R` recomputes the highlighted
Gaussian LC-conmode example from saved fresh fits, or reruns its nuisance fits
with `--refit`. `scripts/analyze.R` and `scripts/summarize.R` regenerate all tables
and the figure. They require the preceding empirical study for saved-paper and
fixed-outcome comparison columns; those prior files remain frozen.

For a fresh fit, reuse the exact private library from the preceding published
comparison, or install the three retained tarballs into
`reproduction_artifacts/Rlib` (with their R dependencies). Set `TMPDIR` to this
study's `tmp` directory and limit math-library threads to one. The original
fits ran on M2MBP / pc-racine1 at nice 20, four workers per host, each capped at
1,800 seconds. All source changes and outputs are research-only.

The main specification was selected for illustration after the comparison;
bandwidths were tuned using observed data. The
[editorial update record](inputs/robustness_framing.json) verifies preservation of
the numerical evidence and executable estimation code when adopting this
robustness-check presentation. No production np, npRmpi, or Gallery change or
publication is part of this task.

## Artifact note

The reference job 28 completed with a saved fit and raw zero exit. Its text log
contains only its opening stage lines: an early verification sync accidentally
replaced that active log with a partial local copy. Its numerical result,
convergence code, timing and process receipt are retained independently in
`results/fits/28.rds` and `results/process/28.json`. Completion is established
from those records, not from its text log. Subsequent synchronization is strictly
by the preassigned owning host (`scripts/pull.py`); no other owned fit record was
overwritten or rerun.
