from pathlib import Path
import concurrent.futures,csv,datetime,hashlib,json,os,signal,subprocess,sys,time
root=Path(__file__).resolve().parent.parent
os.chdir(root)
host=sys.argv[1]
assert host in ('M2MBP','pc-racine1')
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
os.environ['TMPDIR']=str(root/'tmp')
for path,wanted in json.loads((root/'inputs/execution_sha256.json').read_text()).items():
 assert hashlib.sha256((root/path).read_bytes()).hexdigest()==wanted,path
jobs=[r for r in csv.DictReader((root/'inputs/jobs.csv').open()) if r['host']==host]
# Reference starts first so expensive likelihood work overlaps the np fits.
jobs.sort(key=lambda r:r['kind']!='reference')
def one(row):
 i=int(row['id']);receipt=root/f'results/process/{i:02d}.json'
 assert not receipt.exists() and not (root/f'results/fits/{i:02d}.rds').exists()
 start=time.time();timedout=False
 with (root/f'results/logs/{i:02d}.log').open('x') as log:
  p=subprocess.Popen(['/Library/Frameworks/R.framework/Resources/bin/Rscript','--vanilla',str(root/'scripts/run_job.R'),str(i)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=1800)
  except subprocess.TimeoutExpired:
   timedout=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 info=dict(id=i,host=host,pid=p.pid,returncode=code,timedout=timedout,elapsed=time.time()-start,started_utc=datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat())
 receipt.write_text(json.dumps(info,indent=2)+'\n')
 return info
with (root/f'logs/controller_{host}.jsonl').open('x') as log:
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for info in pool.map(one,jobs):
   log.write(json.dumps(info)+'\n');log.flush();print(info,flush=True)
print('OWNED_RANGE_COMPLETE',host,flush=True)
