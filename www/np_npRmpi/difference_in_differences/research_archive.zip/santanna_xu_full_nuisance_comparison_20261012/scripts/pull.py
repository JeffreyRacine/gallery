from pathlib import Path
import csv,subprocess,concurrent.futures
root=Path(__file__).resolve().parent.parent
jobs=list(csv.DictReader((root/'inputs/jobs.csv').open()))
def pull(host,login,ssh):
 ids=[int(j['id']) for j in jobs if j['host']==host]
 # Each host is authoritative only for its own attempts. Never import stale
 # copies of the other host's logs that were sent for verification.
 include=[]
 for d in ('fits','process','logs'):
  include.append('--include='+d+'/')
  for i in ids:include.append('--include='+f'{d}/{i:02d}.'+{'fits':'rds','process':'json','logs':'log'}[d])
 subprocess.run(['rsync','-az','-e',ssh,*include,'--exclude=*',f'{login}:{root}/results/',str(root/'results')+'/'],check=True)
 subprocess.run(['rsync','-az','-e',ssh,f'{login}:{root}/logs/',str(root/'logs'/host)+'/'],check=True)
with concurrent.futures.ThreadPoolExecutor(2) as pool:
 list(pool.map(lambda a:pull(*a),[('M2MBP','jracine@M2MBP.local','ssh -4'),('pc-racine1','jracine@pc-racine1.mcmaster.ca','ssh')]))
