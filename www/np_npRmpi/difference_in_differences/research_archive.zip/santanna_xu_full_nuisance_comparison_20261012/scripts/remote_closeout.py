from pathlib import Path
import csv,hashlib,json,os,subprocess,sys
root=Path(__file__).resolve().parent.parent
host=sys.argv[1]
jobs=[r for r in csv.DictReader((root/'inputs/jobs.csv').open()) if r['host']==host]
source=json.loads((root/'inputs/execution_sha256.json').read_text())
assert all(hashlib.sha256((root/f).read_bytes()).hexdigest()==h for f,h in source.items())
hashes={};receipts=[]
for j in jobs:
 i=int(j['id']);receipt=root/f'results/process/{i:02d}.json'
 assert receipt.exists(),i
 info=json.loads(receipt.read_text());receipts.append(info)
 assert info['host']==host and info['id']==i
 for f in [receipt,root/f'results/fits/{i:02d}.rds',root/f'results/logs/{i:02d}.log']:
  if f.exists():hashes[str(f.relative_to(root))]=hashlib.sha256(f.read_bytes()).hexdigest()
 text=subprocess.check_output(['ps','-p',str(info['pid']),'-o','command='],text=True).strip() if subprocess.run(['kill','-0',str(info['pid'])],capture_output=True).returncode==0 else ''
 assert not (str(root) in text and 'run_job.R' in text),(info['pid'],text)
screens=subprocess.run(['screen','-ls'],capture_output=True,text=True).stdout
assert f'sx_fresh_{host}' not in screens,screens
out=dict(host=host,owned_jobs=len(jobs),raw_zero=sum(r['returncode']==0 for r in receipts),timeouts=sum(r['timedout'] for r in receipts),source_hashes_verified=len(source),hashes=hashes,screens=screens,owned_worker_pids_absent=True)
(root/f'inputs/remote_closeout_{host}.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='hashes'},indent=2))
