source('R/fit.R')
args<-commandArgs(TRUE);id<-as.integer(args[1]);jobs<-read.csv('inputs/jobs.csv');job<-jobs[jobs$id==id,]
stopifnot(nrow(job)==1L)
a<-new.env(parent=emptyenv());a$stage<-'start';a$warnings<-character();a$evaluations<-list()
start<-proc.time()[['elapsed']]
message('BEGIN ',id,' ',paste(unlist(job),collapse=' '))
ans<-tryCatch(withCallingHandlers({
 switch(job$kind,ps_lc=fit_ps_lc(job$i,job$kernel,a),
  ps_conmode_lc=fit_ps_conmode(job$i,job$kernel,'lc',a),
  ps_conmode_ll=fit_ps_conmode(job$i,job$kernel,'ll',a),
  outcome=fit_or(job$i,job$kernel,a),reference=fit_reference(job$i,a))
},warning=function(w){a$warnings<-c(a$warnings,conditionMessage(w));invokeRestart('muffleWarning')}),error=identity)
ok<-!inherits(ans,'error')
out<-list(id=id,job=job,ok=ok,error=if(ok)'' else conditionMessage(ans),
 fit=if(ok)ans else NULL,audit=as.list(a),elapsed=proc.time()[['elapsed']]-start,
 row_ids=rownames(dat),host=Sys.info()[['nodename']],session=sessionInfo(),np_library=find.package('np'))
saveRDS(out,sprintf('results/fits/%02d.rds',id))
message('END ',id,' ok=',ok,' elapsed=',out$elapsed,' ',out$error)
quit(status=if(ok)0L else 1L)
