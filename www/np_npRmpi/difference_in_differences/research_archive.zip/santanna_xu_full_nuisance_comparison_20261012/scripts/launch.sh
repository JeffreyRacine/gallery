#!/bin/bash
set -eu
cd /Users/jracine/Development/lpdensity/npreg_causal_feasibility_20261011/santanna_xu_full_nuisance_comparison_20261012
export TMPDIR="$PWD/tmp" OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
nice -n 20 /opt/local/bin/python3 scripts/controller.py "$1" > "logs/controller_$1.log" 2>&1
