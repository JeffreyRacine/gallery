#!/bin/bash
set -eu
cd "$(dirname "$0")/.."
mkdir -p tmp reproduction_artifacts/Rlib logs
export TMPDIR="$PWD/tmp" OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
export R_LIBS="$PWD/reproduction_artifacts/Rlib"
RBIN=/Library/Frameworks/R.framework/Resources/bin/R
for archive in roptim_0.1.7.tar.gz compdid_corrected_0.1.0.tar.gz np_0.80-1.tar.gz; do
  nice -n 20 "$RBIN" CMD INSTALL --library="$R_LIBS" "reproduction_artifacts/tarballs/$archive" > "logs/install_$archive.log" 2>&1
done
