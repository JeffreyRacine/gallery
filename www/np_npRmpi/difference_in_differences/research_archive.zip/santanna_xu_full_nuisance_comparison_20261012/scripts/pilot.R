source('R/fit.R')
x<-make_x(1);y<-factor(max.col(cells),levels=1:4,labels=c('11','10','01','00'))
for(kernel in c('epanechnikov','gaussian')) {
 b<-shared_bw(x,cells[,1],c(.8,.8),kernel,'lc')
 p<-npreghat(bws=b,txdat=x,y=cells,leave.one.out=TRUE,output='apply')
 stopifnot(all(dim(p)==dim(cells)),max(abs(rowSums(p)-1))<1e-12)
 for(type in c('lc','ll')) {
  cb<-npcdensbw(xdat=x,ydat=y,bws=c(0,rep(.8/sqrt(5),2),rep(.8,9)),bandwidth.compute=FALSE,
    regtype=type,cxkertype=kernel,uxkertype='liracine',uykertype='aitchisonaitken')
  elapsed<-system.time(for(j in c(1,100,500)) {
   f<-npconmode(bws=cb,txdat=x[-j,,drop=FALSE],tydat=y[-j],exdat=x[j,,drop=FALSE],
     probabilities=TRUE,proper=type!='lc',se=FALSE)
   pr<-predict(f,type='prob');print(pr)
   stopifnot(setequal(colnames(pr),levels(y)),abs(sum(pr)-1)<1e-10)
   if(type=='lc')stopifnot(max(abs(p[j,]-pr[,levels(y)]))<1e-10)
  })
  print(list(kernel=kernel,type=type,elapsed=elapsed))
 }
}
print(lapply(ref$locpol$ps_fit,function(z)list(range=range(z$fitted.values),row_sums=range(rowSums(z$fitted.values)))))
cat('PILOT_PASS\n')
