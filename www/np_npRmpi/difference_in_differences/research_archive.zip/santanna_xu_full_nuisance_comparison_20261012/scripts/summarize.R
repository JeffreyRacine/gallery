source('R/data.R')
jobs<-read.csv('inputs/jobs.csv');brows<-list();warnings<-list();refs<-list()
for(j in seq_len(nrow(jobs))) {
 job<-jobs[j,];f<-sprintf('results/fits/%02d.rds',job$id);if(!file.exists(f))next
 z<-readRDS(f)
 if(length(z$audit$warnings))warnings[[length(warnings)+1L]]<-data.frame(id=job$id,warning=unique(z$audit$warnings))
 b<-z$audit$selected
 if(!is.null(b))brows[[length(brows)+1L]]<-data.frame(id=job$id,kind=job$kind,i=job$i,kernel=job$kernel,
  continuous_halfwidth=b$theta[1],lambda=b$theta[2],objective=b$value,convergence=b$convergence)
 if(job$kind=='reference' && z$ok) {
  old<-readRDS(sprintf('../santanna_xu_assessment/results/empirical/psbw_%d.rds',job$i))
  new<-z$fit$bws
  refs[[length(refs)+1L]]<-data.frame(i=job$i,old_h=old$bw_cv[1],old_lambda=old$bw_cv[2],old_objective=old$value,old_code=old$convergence,
   BFGS_h=new$bw_cv[1],BFGS_lambda=new$bw_cv[2],BFGS_objective=new$value,BFGS_code=new$convergence,elapsed=z$elapsed)
 }
}
write.csv(do.call(rbind,brows),'results/shared_bandwidths.csv',row.names=FALSE)
write.csv(do.call(rbind,warnings),'results/warnings.csv',row.names=FALSE)
write.csv(do.call(rbind,refs),'results/reference_BFGS.csv',row.names=FALSE)
baseline<-lapply(c(1,3,4),function(i) {
 p<-ref$locpol$ps_fit[[i]]$fitted.values
 constant<-(matrix(colSums(cells),nrow(cells),4,byrow=TRUE)-cells)/(nrow(cells)-1)
 data.frame(i=i,author_brier=mean(rowSums((cells-p)^2)),constant_loo_brier=mean(rowSums((cells-constant)^2)),
  constant_author_rmse=sqrt(mean((constant-p)^2)))
})
write.csv(do.call(rbind,baseline),'results/propensity_baselines.csv',row.names=FALSE)
out<-read.csv('results/main_results.csv')
draw<-function() {
 par(mfrow=c(2,2),mar=c(4.3,4.2,2.5,.6),las=1)
 colors<-c('#626872','#007F86','#B96A19')
 for(i in 1:4) {
  z<-out[out$i==i & (out$kind=='paper' | (out$stage=='fresh_outcomes' &
    ((out$kind=='ps_conmode_lc' & out$kernel=='gaussian') | out$kind=='ps_lc_mixed'))),]
  z<-z[match(c('paper','ps_conmode_lc','ps_lc_mixed'),z$kind),]
  stopifnot(all(z$ok));low<-z$ATT-qnorm(.975)*z$cluster_se;high<-z$ATT+qnorm(.975)*z$cluster_se
  plot(1:3,z$ATT,ylim=range(c(0,low,high)),xlim=c(.6,3.4),xaxt='n',xlab='',ylab='ATT',
    main=z$label[1],pch=19,col=colors,cex.main=.9)
  abline(h=0,lty=3,col='gray65');arrows(1:3,low,1:3,high,angle=90,code=3,length=.045,col=colors)
  points(1:3,z$ATT,pch=19,col=colors)
  axis(1,1:3,c('Paper','Gaussian\nLC conmode','Closest PS\n+ Gaussian OR'),cex.axis=.74)
 }
}
png('figures/fresh_nuisance_results.png',width=1700,height=1100,res=175);draw();dev.off()
pdf('figures/fresh_nuisance_results.pdf',width=9.7,height=6.3);draw();dev.off()
cat('SUMMARY_COMPLETE\n')
