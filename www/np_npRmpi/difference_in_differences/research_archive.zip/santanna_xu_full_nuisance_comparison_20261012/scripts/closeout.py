from pathlib import Path
import csv,hashlib,json,subprocess
root=Path(__file__).resolve().parent.parent
workspace=root.parents[2]
assert str(workspace)=='/Users/jracine/Development'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
jobs=list(csv.DictReader((root/'inputs/jobs.csv').open()))
receipts=[]
for row in jobs:
 i=int(row['id']);receipt=root/f'results/process/{i:02d}.json'
 assert receipt.exists(),i
 r=json.loads(receipt.read_text());assert r['host']==row['host'];receipts.append(r)
 if r['returncode']==0:assert (root/f'results/fits/{i:02d}.rds').exists()
sources=json.loads((root/'inputs/execution_sha256.json').read_text())
assert all(digest(root/f)==h for f,h in sources.items())
provenance=json.loads((root/'inputs/predecessors.json').read_text())
assert all(digest(workspace/f)==h for f,h in provenance.items())
old=root.parent/'santanna_xu_empirical_sensitivity_20261012'
manifest=json.loads((old/'FINAL_SHA256.json').read_text())
assert all(digest(old/f)==h for f,h in manifest.items())
remote={}
for host in ['M2MBP','pc-racine1']:
 r=json.loads((root/f'inputs/remote_closeout_{host}.json').read_text())
 assert all(digest(root/f)==h for f,h in r['hashes'].items())
 remote[host]=dict(hash_matches=len(r['hashes']),jobs=r['owned_jobs'],raw_zero=r['raw_zero'],timeouts=r['timeouts'])
state={repo:dict(head=subprocess.check_output(['git','-C',str(workspace/repo),'rev-parse','HEAD'],text=True).strip(),status=subprocess.check_output(['git','-C',str(workspace/repo),'status','--porcelain'],text=True)) for repo in ['np-master','np-npRmpi']}
(root/'inputs/workspace_after.json').write_text(json.dumps(state,indent=2)+'\n')
before=json.loads((root/'inputs/workspace_before.json').read_text())
proof=dict(planned_jobs=len(jobs),receipts=len(receipts),raw_zero=sum(r['returncode']==0 for r in receipts),timeouts=sum(r['timedout'] for r in receipts),
 prelaunch_sources_unchanged=len(sources),predecessor_files_unchanged=len(manifest),remote=remote,package_state_unchanged=before==state,
 fresh_example_agreement=(root/'results/verification_refit/agreement.txt').read_text().strip())
(root/'inputs/closeout.json').write_text(json.dumps(proof,indent=2)+'\n')
excluded={'FINAL_SHA256.json'}
files=[f for f in root.rglob('*') if f.is_file() and f.name not in excluded and not any(x in f.relative_to(root).parts for x in ['tmp','Rlib','__pycache__'])]
(root/'FINAL_SHA256.json').write_text(json.dumps({str(f.relative_to(root)):digest(f) for f in sorted(files)},indent=2)+'\n')
print(json.dumps(proof,indent=2))
