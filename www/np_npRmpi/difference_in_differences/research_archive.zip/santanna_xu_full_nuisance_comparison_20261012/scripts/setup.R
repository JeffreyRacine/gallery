source('R/load.R')
capture.output(sessionInfo(),file='logs/installed_build.txt')
capture.output(list(np_path=find.package('np'),compdid_path=find.package('compdid')),
 file='logs/installed_build.txt',append=TRUE)
Rcpp::sourceCpp('src/reference_bfgs.cpp',cacheDir='tmp/reference_cache',rebuild=FALSE)
source('scripts/pilot.R')
