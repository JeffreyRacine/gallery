# All post-fit comparisons use base R and saved records; no fitting occurs here.
source('R/data.R')
jobs<-read.csv('inputs/jobs.csv')
records<-lapply(sprintf('results/fits/%02d.rds',jobs$id),function(f)if(file.exists(f))readRDS(f) else NULL)
names(records)<-jobs$id
clip_ps<-function(p)pmin(pmax(p,.01),.99)
old<-'../santanna_xu_empirical_sensitivity_20261012'
paper<-readRDS(file.path(old,'results/paper_replication.rds'))
fixed<-lapply(sprintf('%s/results/fixed/%02d.rds',old,1:8),readRDS)
getrecord<-function(kind,i,kernel)records[[as.character(jobs$id[jobs$kind==kind & jobs$i==i & jobs$kernel==kernel])]]
psrows<-list();status<-list();bandwidths<-list()
for(j in seq_along(records)) {
 z<-records[[j]];job<-jobs[j,]
 ended<-file.exists(sprintf('results/process/%02d.json',job$id))
 status[[j]]<-data.frame(job,complete=!is.null(z) || ended,ok=if(is.null(z))FALSE else z$ok,
  elapsed=if(is.null(z))NA_real_ else z$elapsed,
  error=if(is.null(z))if(ended)'Process ended without fit record; see raw exit/timeout receipt' else 'pending' else z$error)
 if(is.null(z) || !z$ok)next
 stopifnot(identical(z$row_ids,rownames(dat)))
 if(job$kind=='outcome')next
 p<-z$fit$raw;q<-clip_ps(p);r<-ref$locpol$ps_fit[[job$i]]$fitted.values
 stopifnot(identical(dim(p),dim(r)))
 psrows[[length(psrows)+1L]]<-data.frame(id=job$id,i=job$i,kind=job$kind,kernel=job$kernel,
  rmse=sqrt(mean((q-r)^2)),raw_vs_clipped_author_rmse=sqrt(mean((p-r)^2)),mae=mean(abs(q-r)),
  rmse_11=sqrt(mean((q[,1]-r[,1])^2)),rmse_10=sqrt(mean((q[,2]-r[,2])^2)),
  rmse_01=sqrt(mean((q[,3]-r[,3])^2)),rmse_00=sqrt(mean((q[,4]-r[,4])^2)),
  min_raw=min(p),max_raw=max(p),max_rowsum_error=max(abs(rowSums(p)-1)),
  clipped_entries=sum(p<.01 | p>.99),brier=mean(rowSums((cells-p)^2)),
  logloss=-mean(log(pmax(p[cells==1],1e-5))),
  outer_converged=if(job$kind=='reference')z$fit$outer_converged else if(job$kind=='ps_lc')z$fit$selection$convergence==0L else NA)
}
write.csv(do.call(rbind,status),'results/job_status.csv',row.names=FALSE)
if(length(psrows)) {
 psout<-do.call(rbind,psrows);write.csv(psout,'results/propensity_comparison.csv',row.names=FALSE)
 rank<-aggregate(cbind(rmse,mae)~kind+kernel,psout,FUN=mean)
 rank$designs<-vapply(seq_len(nrow(rank)),function(i)sum(psout$kind==rank$kind[i] & psout$kernel==rank$kernel[i]),integer(1))
 rank<-rank[order(rank$rmse),];write.csv(rank,'results/propensity_ranking.csv',row.names=FALSE)
 print(rank,row.names=FALSE)
}
g<-as.integer(factor(cluster));G<-max(g);n<-nrow(dat);B<-ref$locpol$nboot
rows<-list();scores<-list();set.seed(ref$locpol$seed)
for(i in 1:4) {
 lo<-(1-sqrt(5))/2;hi<-(1+sqrt(5))/2
 mult<-matrix(ifelse(rbinom(G*B,1,hi/sqrt(5))==1,lo,hi),G,B)
 cluster_stats<-function(s) {
  sums<-drop(rowsum(s$influence,g,reorder=TRUE));draws<-drop(crossprod(sums,mult))/n
  list(se=IQR(draws)/(qnorm(.75)-qnorm(.25)),share=max(sums^2)/sum(sums^2))
 }
 p<-paper[[i]]$independent;pc<-cluster_stats(p)
 stopifnot(abs(pc$se-paper[[i]]$clustered$nonstationary$se)<1e-10)
 add<-function(kind,kernel,stage,s,error='') {
  ok<-is.list(s) && !inherits(s,'error');cs<-if(ok)cluster_stats(s) else NULL
  rows[[length(rows)+1L]]<<-data.frame(i=i,outcome=ref$locpol$ynames[i],label=ref$table4$outcome[i],
   kind=kind,kernel=kernel,stage=stage,ok=ok,error=if(inherits(s,'error'))conditionMessage(s) else error,
   ATT=if(ok)s$att else NA_real_,cluster_se=if(ok)cs$se else NA_real_,
   diff=if(ok)s$att-p$att else NA_real_,diff_paper_se=if(ok)(s$att-p$att)/pc$se else NA_real_,
   min_ess=if(ok)min(s$ess) else NA_real_,max_weight=if(ok)s$maximum_weight else NA_real_,
   largest_cluster_variance_share=if(ok)cs$share else NA_real_)
  if(ok)scores[[paste(i,kind,kernel,stage,sep='_')]]<<-s
 }
 add('paper','author','paper',p)
 design<-if(i==2L)1L else i;y<-dat[[ref$locpol$ynames[i]]]
 for(kernel in c('epanechnikov','gaussian')) {
  outcome<-getrecord('outcome',i,kernel)
  fid<-2*i-if(kernel=='epanechnikov')1L else 0L
  for(kind in c('ps_lc','ps_conmode_lc','ps_conmode_ll','reference')) {
   if(kind=='reference' && kernel=='gaussian')next
   prop<-getrecord(kind,design,kernel)
   for(stage in c('fixed_outcomes','fresh_outcomes')) {
    or<-if(stage=='fixed_outcomes')list(ok=fixed[[fid]]$ok,fit=list(mu=fixed[[fid]]$audit$mu)) else outcome
    ready<-!is.null(prop) && prop$ok && !is.null(or) && or$ok
    if(ready && kind=='reference')ready<-prop$fit$outer_converged
    s<-if(ready)tryCatch(sx_score(y,d,post,clip_ps(prop$fit$raw),or$fit$mu),error=identity) else NULL
    add(kind,kernel,stage,s,if(!ready)'propensity or outcome fit unavailable / nonconverged' else '')
   }
  }
 }
 # MIXED_KERNEL_ADDENDUM.md: select propensity family by RMSE, not by ATT.
 prop<-getrecord('ps_lc',design,'epanechnikov')
 outcome<-getrecord('outcome',i,'gaussian')
 for(stage in c('fixed_outcomes','fresh_outcomes')) {
  or<-if(stage=='fixed_outcomes')list(ok=fixed[[2*i]]$ok,fit=list(mu=fixed[[2*i]]$audit$mu)) else outcome
  ready<-!is.null(prop) && prop$ok && !is.null(or) && or$ok
  s<-if(ready)tryCatch(sx_score(y,d,post,clip_ps(prop$fit$raw),or$fit$mu),error=identity) else NULL
  add('ps_lc_mixed','gaussian',stage,s,if(!ready)'fit unavailable' else '')
 }
}
out<-do.call(rbind,rows);write.csv(out,'results/main_results.csv',row.names=FALSE)
saveRDS(scores,'results/scores.rds')
print(out[out$stage=='fresh_outcomes',c('outcome','kind','kernel','ok','ATT','cluster_se')],row.names=FALSE)
cat('ANALYSIS_COMPLETE records=',sum(!vapply(records,is.null,logical(1))),'/',nrow(jobs),'\n')
