source('R/fit.R')
jobs<-read.csv('inputs/jobs.csv');checks<-list();q<-0L
check<-function(id,kind,row,diff,proved=TRUE) {
 q<<-q+1L;checks[[q]]<<-data.frame(id=id,kind=kind,row=row,difference=diff,proved=proved)
 if(proved)stopifnot(is.finite(diff),diff<1e-7)
}
kernel_weights<-function(x,at,bw,kernel,omit=integer()) {
 w<-rep(1,nrow(x))
 for(j in 1:2) {
  u<-(x[[j]]-at[[j]])/bw[j]
  w<-w*if(kernel=='gaussian')exp(-u^2/2) else pmax(0,1-u^2/5)*(abs(u)<=sqrt(5))
 }
 for(j in 3:11)w<-w*ifelse(x[[j]]==at[[j]],1,bw[j])
 w[omit]<-0;w
}
for(id in jobs$id) {
 file<-sprintf('results/fits/%02d.rds',id);if(!file.exists(file))next
 z<-readRDS(file);if(!z$ok)next
 x<-make_x(z$job$i);kernel<-z$job$kernel
 if(z$job$kind %in% c('ps_lc','ps_conmode_lc')) {
  b<-z$fit$bws;bw<-if(z$job$kind=='ps_lc')b$bw else b$xbw
  for(j in unique(unlist(lapply(1:4,function(g){r<-which(cells[,g]==1);r[unique(round(seq(1,length(r),length.out=8)))]})))) {
   w<-kernel_weights(x,x[j,,drop=FALSE],bw,kernel,j)
   expected<-drop(crossprod(w,cells))/sum(w)
   if(z$job$kind=='ps_conmode_lc')expected<-(1-b$ybw)*expected+b$ybw/3*(1-expected)
   check(id,'literal_LC_kernel',j,max(abs(expected-z$fit$raw[j,])))
  }
 }
 if(z$job$kind=='outcome') {
  y<-dat[[ref$locpol$ynames[z$job$i]]]
  for(g in 2:4) {
   tr<-which(cells[,g]==1);te<-which(cells[,1]==1);b<-z$fit$bws[[g]]
   selected<-unique(c(tr[unique(round(seq(1,length(tr),length.out=6)))],te[unique(round(seq(1,length(te),length.out=6)))]))
   for(j in selected) {
    w<-kernel_weights(x[tr,,drop=FALSE],x[j,,drop=FALSE],b$bw,kernel,which(tr==j))
    Z<-cbind(1,sweep(as.matrix(x[tr,1:2]),2,as.numeric(x[j,1:2]),'-'))
    A<-Z*sqrt(w);yv<-y[tr]*sqrt(w)
    proved<-qr(A,tol=1e-10)$rank==3L && kappa(A,exact=TRUE)<1e8
    delta<-if(proved)abs(qr.solve(A,yv,tol=1e-10)[1]-z$fit$mu[j,g]) else NA_real_
    check(id,paste0('literal_LL_QR_cell_',g),j,delta,proved)
   }
  }
 }
}
if(file.exists('results/scores.rds')) {
 scores<-readRDS('results/scores.rds');old<-'../santanna_xu_empirical_sensitivity_20261012'
 for(name in names(scores)) {
  if(grepl('_paper_',name))next
  # The saved-score comparison itself is independent of any package estimator.
  tok<-strsplit(name,'_',fixed=TRUE)[[1]];i<-as.integer(tok[1]);s<-scores[[name]]
  jobrows<-read.csv('results/main_results.csv')
  row<-jobrows[paste(jobrows$i,jobrows$kind,jobrows$kernel,jobrows$stage,sep='_')==name,]
  design<-if(i==2L)1L else i
  pkind<-if(row$kind=='ps_lc_mixed')'ps_lc' else row$kind
  pkernel<-if(row$kind=='ps_lc_mixed')'epanechnikov' else row$kernel
  pid<-jobs$id[jobs$kind==pkind & jobs$i==design & jobs$kernel==pkernel]
  prop<-readRDS(sprintf('results/fits/%02d.rds',pid))$fit$raw
  if(row$stage=='fresh_outcomes') {
   oid<-jobs$id[jobs$kind=='outcome' & jobs$i==i & jobs$kernel==row$kernel]
   mu<-readRDS(sprintf('results/fits/%02d.rds',oid))$fit$mu
  } else {
   fid<-2*i-if(row$kernel=='epanechnikov')1L else 0L
   mu<-readRDS(sprintf('%s/results/fixed/%02d.rds',old,fid))$audit$mu
  }
  # Package formula touches irrelevant entries; zero those algebraic zero terms.
  mu[is.na(mu)]<-0
  ns<-compdid::drdid_nonstationary(dat[[ref$locpol$ynames[i]]],d,post,clip_ps(prop),mu)
  check(pid,paste('score_IF',name),i,max(abs(c(ns$ATT-s$att,ns$att.inf.func-s$influence))))
 }
}
out<-do.call(rbind,checks);write.csv(out,'results/independent_checks.csv',row.names=FALSE)
print(aggregate(cbind(proved=as.integer(out$proved),checks=rep(1,nrow(out))),list(kind=out$kind),sum))
cat('INDEPENDENT_CHECKS_PASS max=',max(out$difference,na.rm=TRUE),'\n')
