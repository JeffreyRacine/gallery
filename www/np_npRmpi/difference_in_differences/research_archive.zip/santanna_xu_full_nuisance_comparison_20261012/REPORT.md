# Robustness check using np: the tariff-evasion application

12 October 2026. We revisit Sant’Anna–Xu’s empirical tariff-evasion application
using the same data and analogous functions in the `np` package, freshly
estimating both nuisance stages and their bandwidths. The resulting estimates
are in broad agreement with the authors’ published results. This provides a
same-data robustness check using an alternative implementation of the nuisance
estimators in their composition-robust difference-in-differences procedure.

The example uses Gaussian local-constant (LC) `npconmode` class probabilities
and Gaussian local-linear `npreg` outcome regressions. All four estimated effects
have the published negative sign, and three point estimates differ by at most
about half of the corresponding published clustered standard error. The
shipment-value effect is substantially smaller; log bribes have a wider interval
and no longer meet the conventional 5% significance threshold. These differences
qualify the agreement while preserving the broad pattern of lower bribery.

## Main results: fully re-estimated np robustness check

Composition-robust ATT; clustered multiplier standard errors in parentheses.

| Outcome | Sant’Anna–Xu | np robustness check |
| --- | --- | --- |
| Bribe probability | -0.3068 (0.1086) | -0.2853 (0.1372) |
| Log(1 + bribe) | -2.8884 (0.9148) | -2.4308 (1.6439) |
| Log(1 + bribe / shipment value) | -0.0274 (0.0145) | -0.0060 (0.0039) |
| Log(1 + bribe / shipment tonnage) | -1.1307 (0.6346) | -0.8354 (1.1510) |

Every np entry uses newly estimated propensities, outcome means and bandwidths.
The authors’ saved nuisance estimates and bandwidth values serve only as
comparators. Bribe probability remains significant at 5%; both ratio outcomes
have normal 95% clustered intervals containing zero, as in the published results.

## Adaptations using np

The following choices explain how the example implements the two nuisance
stages with analogous package functions.

| Component | Authors’ procedure | np robustness check |
| --- | --- | --- |
| Generalized propensity scores | Local multinomial-logit likelihood for the four treatment/time cells | LC conditional class probabilities from `npconmode`, with `npcdensbw` likelihood cross-validation |
| Propensity bandwidths | One common continuous bandwidth and one common unordered smoothing parameter | Separately selected predictor bandwidths and a class-response smoothing parameter |
| Outcome regressions | Local-linear fits with two bandwidths shared across the four cells | Local-linear `npreg` fits with the same shared two-parameter structure, freshly tuned by pooled leave-one-out squared error |
| Continuous kernels | Epanechnikov | Gaussian in the main example; Epanechnikov alternatives retained below as sensitivity comparisons |
| Unordered smoothing | The paper specifies equality/mismatch weights; the archived code has a [documented discrepancy](../santanna_xu_assessment/README.md#corrected-discrepancy-and-numerical-checks) | Standard Li–Racine predictor kernels, plus normalized Aitchison–Aitken class-response smoothing for `npconmode` |

The Gaussian kernel and separate propensity bandwidths are choices for this
robustness specification. The package also supports Epanechnikov kernels, and
the retained LC indicator-regression comparison uses shared bandwidths. The
class-probability estimator is an alternative to the authors’ local multinomial
logit; the outcome regressions retain the local-linear method. Numerical
handling of locally singular regressions can also differ between implementations.

The 1,084-observation sample, covariates, outcome definitions, [0.01,0.99]
propensity clipping convention, normalized ATT score and clustered multiplier
inference are retained. The ATT score and inference are independently coded in
R, with `np` supplying both nuisance stages. The shared outcome-bandwidth search
uses an explicit R `optim` wrapper over public `np` fitting methods.

The main specification was chosen for illustration after the bounded comparison.
All fitted candidates and failures remain available in the supporting results
below, under the [original plan](PLAN.md) and the
[one-specification addendum](MIXED_KERNEL_ADDENDUM.md). Each bandwidth objective
uses observed data; none is fitted to the authors’ propensity arrays or desired
ATT values.

## Supporting comparison: propensity estimators

Shared-bandwidth Epanechnikov LC indicator regression gives the closest
propensity arrays among the completed np families. It does not give the closest
final ATT table: the effect of changing propensities depends on the outcome
regressions and the resulting weights.

RMSE compares the clipped fitted arrays with archived clipped author arrays,
averaged equally over three distinct predictor designs. The first two outcomes
have exactly the same predictors and share their propensity fits. Incomplete
families are shown with their actual denominator and are not eligible to win
the complete-family ranking. Reference BFGS is separate from the np alternatives.

| Propensity family | Kernel | Mean RMSE vs archived PS | Completed designs |
| --- | --- | --- | --- |
| Reference BFGS | epanechnikov | 0.1363 | 1/3 |
| LC indicator regression | epanechnikov | 0.1454 | 3/3 |
| LL npconmode | epanechnikov | 0.1744 | 2/3 |
| LC indicator regression | gaussian | 0.1775 | 3/3 |
| LC npconmode | epanechnikov | 0.1823 | 2/3 |
| LL npconmode | gaussian | 0.1831 | 3/3 |
| LC npconmode | gaussian | 0.1874 | 3/3 |

RMSE around 0.15 is not near identity. These are the closest among the declared
methods, not a claim that the archived propensities have been precisely recovered.
The archived arrays are a descriptive benchmark, not known true probabilities.

For scale, a leave-one-out constant class-frequency benchmark has mean RMSE
0.1215 against the archived arrays, despite a worse Brier loss against observed
classes (about 0.402). The fresh Gaussian LC-conmode fits have Brier losses
0.179–0.182. This illustrates why closeness to saved propensities alone cannot
establish nuisance accuracy or final ATT agreement; see the retained propensity
baseline and comparison CSVs. The constant benchmark is a diagnostic, not an
additional fitted ATT specification.

## Supporting comparison: BFGS reference experiment

Only the outer propensity optimizer changes from Nelder–Mead to BFGS in a separate
copy of the corrected reference C++ file. The Epanechnikov kernel, inner local
multinomial fit, start (0.8, 0.8), tolerances and maxit stay unchanged.

| Design | Nelder–Mead code | Nelder–Mead objective | BFGS code | BFGS objective | BFGS h | BFGS lambda |
| --- | --- | --- | --- | --- | --- | --- |
| 3 | 10 | 0.1149759 | 0 | 0.1151445 | 0.9853 | 0.1471 |

Of three distinct reference designs, 1 returned numerical fit records;
1 reported BFGS convergence code 0. The
remaining attempt outcomes are recorded in the failure ledger below. A time-limit
exit means noncompletion within the declared computational budget, not a
mathematical proof of nonconvergence.

The bribe/log-bribe design and the tonnage design reached the 30-minute cap;
the shipment-value design returned code 0 in about 228 seconds. A brief stack
sample of the bribe design found it in the tighter second-stage refinement,
evaluating inner multinomial likelihood fits. This locates the sampled work;
it does not establish eventual convergence or fully diagnose the slow endpoint.

Convergence code 0 is the outer optimizer's reported convergence, not proof of
the global minimum or of every inner likelihood solve. Compare the objective
values directly: a converged BFGS endpoint can have a larger objective than the
retained code-10 Nelder–Mead endpoint. Removing code 10 does not establish that
Epanechnikov caused it, or that the original reference has become universally
robust. Full reference fits and failures are retained with the np fits.

## Sensitivity results: every predeclared paired-kernel specification

Both stages freshly fitted; ATT (clustered SE). “Failed” is a required fitting
stage failure and is never filled by a different estimator or bandwidth.

| Propensities | Kernel (both stages) | Bribe probability | Log bribe | Value ratio | Tonnage ratio |
| --- | --- | --- | --- | --- | --- |
| LC indicator regression | epanechnikov | -0.4271 (0.0994) | -4.0041 (1.0069) | Failed | -1.3512 (0.4763) |
| LC indicator regression | gaussian | -0.3413 (0.1479) | -2.8520 (1.4944) | 0.0231 (0.0258) | -1.4848 (0.9783) |
| LC npconmode | epanechnikov | -0.2700 (0.1446) | -2.1497 (1.7488) | Failed | Failed |
| LC npconmode | gaussian | -0.2853 (0.1372) | -2.4308 (1.6439) | -0.0060 (0.0039) | -0.8354 (1.1510) |
| LL npconmode | epanechnikov | -0.7199 (0.5546) | -2.3688 (2.9122) | Failed | Failed |
| LL npconmode | gaussian | -0.4854 (0.1801) | -2.3942 (2.7329) | 0.0045 (0.0073) | 0.3204 (3.1992) |
| Reference BFGS | epanechnikov | Failed | Failed | Failed | Failed |

The alternative local-linear conditional probabilities use `npconmode`'s explicit
proper-probability projection. They do not systematically improve agreement.
The native conditional searches allow separate bandwidths for every predictor
and the response class. The LC indicator and outcome regression comparisons use
two shared bandwidths: one for the two normalized continuous predictors and one
for all nine unordered predictors.

## Separating propensity and outcome changes

This table holds the closest propensity fit fixed. Its middle column retains
published outcome bandwidths only as a stage-isolation diagnostic. It is not the
fully fresh main example. “Closest PS” means shared-bandwidth Epanechnikov LC
indicator regressions selected by the declared propensity RMSE ranking. The
mixed-kernel column uses Gaussian outcome regressions for all four outcomes.

| Outcome | Paper | Closest PS + published-bandwidth Epan OR | Closest PS + freshly tuned Epan OR | Closest PS + freshly tuned Gaussian OR |
| --- | --- | --- | --- | --- |
| Bribe probability | -0.3068 (0.1086) | -0.2674 (0.1268) | -0.4271 (0.0994) | -0.4272 (0.0994) |
| Log(1 + bribe) | -2.8884 (0.9148) | -2.5231 (1.1276) | -4.0041 (1.0069) | -4.1224 (1.0111) |
| Log(1 + bribe / shipment value) | -0.0274 (0.0145) | 0.0037 (0.0097) | Failed | 0.0045 (0.0108) |
| Log(1 + bribe / shipment tonnage) | -1.1307 (0.6346) | -1.9905 (0.7567) | -1.3512 (0.4763) | -1.6884 (0.5335) |

This explains why the earlier partially reimplemented main table was closer:
it retained author propensities and author outcome bandwidths. Agreement at those
values did not establish that fresh tuning would produce the same table.

The fully fresh mixed-kernel specification completes all four outcomes but
reverses the small shipment-value point estimate. It remains a supporting
sensitivity result alongside the main Gaussian LC-conmode example.

![ATT estimates and normal 95% clustered intervals: published results, the main np robustness check and the mixed-kernel sensitivity specification](figures/fresh_nuisance_results.png)

This figure was generated for the comparison; it does not reproduce an empirical
figure from the paper.

## Failures and verification

| Job | Stage | Design / outcome | Kernel | Condition |
| --- | --- | --- | --- | --- |
| 11 | ps_conmode_lc | 4 | epanechnikov | C_np_density_conditional_bw: optimizer returned a bandwidth candidate with invalid raw objective |
| 17 | ps_conmode_ll | 4 | epanechnikov | C_np_density_conditional_bw: optimizer returned a bandwidth candidate with invalid raw objective |
| 23 | outcome | 3 | epanechnikov | all(is.finite(mu[c(tr, te), g])) is not TRUE |
| 27 | reference | 1 | epanechnikov | Timed out at 1,800 seconds (raw exit -9) |
| 29 | reference | 4 | epanechnikov | Timed out at 1,800 seconds (raw exit -9) |

The shipment-value Epanechnikov outcome selector converged, but eleven required
counterfactual predictions in the treated/pre fit have zero total kernel weight.
The two conditional-selector failures report invalid raw objectives; they are
retained as search failures without asserting an unproved geometric cause.
No retries, response clipping, silent estimator substitution or package repair
was used. The mixed-kernel specification was added explicitly for all four rows.

There are 29 planned fit attempts, 24 raw zero exits and 2
timeouts. Statistical failures exit nonzero and remain in the process ledger.
634 independent numerical checks passed, maximum absolute discrepancy
4.32e-11. These cover literal LC product-kernel sums, selected full-rank
weighted-QR outcome predictions, and the independent ATT/influence formula
against `compdid`. 20 sampled checks are explicitly marked
unproved rather than silently counted as passes. These are focused checks of this
example, not package release qualification. The runnable retained-fit example
recomputes all four highlighted ATT and clustered SE rows within 1e-10.
The separate fresh execution of `example.R --refit` reselected every bandwidth
and re-estimated both nuisance stages; its four ATT/SE rows agree with the first
run to 4.0e-15 (`results/verification_refit/agreement.txt`).

## Method and reproducibility

- Same 1,084 observations; treatment/time cell counts 120, 56, 824, 84;
  131 clusters, with the largest containing 550 observations (50.7%).
- Each probability is estimated leave-one-out with its selected bandwidths held
  fixed. LC indicator regressions share weights and sum to one before clipping.
  Native class probabilities use actual delete-one `npconmode` evaluations.
- Shared LC propensity bandwidths minimize joint Brier loss. Conditional LC
  uses CVML; conditional LL uses CVLS. Native searches use two starts and a fixed
  seed. Shared searches use two declared starts and optimize log(h), logit(lambda).
- Outcome bandwidths minimize pooled leave-one-out squared error over all four
  groups, preserving the paper's shared-bandwidth structure. The ATT uses
  leave-one-out own-group and external counterfactual outcome predictions.
- Continuous kernels are second order; h/sqrt(5) maps the declared Epanechnikov
  halfwidth to public np bandwidth units, with the same variance parameterization
  for Gaussian. Unordered predictors use Li–Racine kernels. Conditional class
  response smoothing uses the normalized Aitchison–Aitken kernel.
- Clip fresh propensities to [0.01,0.99] without renormalizing, matching the saved
  convention; retain raw arrays. Apply the normalized composition-robust score.
- Use 9,999 common Mammen cluster multipliers, seed 1234, and IQR-based scale, as
  in the verified earlier reproduction. No nuisance refitting in the multiplier
  calculation and no new finite-sample inference guarantee.

The [paper](https://psantanna.com/files/DiD_CC.pdf) supplies the published comparison;
the archived reference provenance is in `inputs/author_provenance.json`. The
previous categorical-kernel discrepancy and different singular-solve policies
remain reasons not to expect byte-for-byte agreement. All original data and
earlier studies are preserved; no production np/npRmpi or Gallery files are edited.

From this directory, reproduce the highlighted table without fitting:

```sh
Rscript --vanilla example.R
```

To freshly refit that entire example, use the retained private installation.
On another compatible Mac, `bash scripts/install_private.sh` installs the exact
retained tarballs into `reproduction_artifacts/Rlib` (assuming their standard R
dependencies are installed), then:

```sh
mkdir -p tmp
TMPDIR="$PWD/tmp" OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  Rscript --vanilla example.R --refit
```

The latter writes separate `results/example_refit` records and refuses to
overwrite an existing refit. `scripts/run_job.R` and `inputs/jobs.csv` specify
every original attempt, including BFGS. `results/` contains raw fits, failures,
exit receipts, score arrays and complete CSV comparisons. `inputs/execution_sha256.json`
binds the pre-launch sources; `FINAL_SHA256.json` binds the finished research
artifact. Host-owned receipt verification and preserved-tree checks are in
`inputs/closeout.json` and `inputs/remote_closeout_*.json`.
The [editorial update record](inputs/robustness_framing.json) verifies that the
robustness-check presentation leaves all numerical evidence and executable
estimation code unchanged from the completed study. The
[artifact note](README.md#artifact-note) documents the partial text log for
reference job 28; its complete numerical RDS and raw exit receipt are retained.
