# Sequeira application: replication and outcome-kernel sensitivity

October 12, 2026. Jeffrey accepts the bounded simulation RMSE evidence and
requests replication of the paper's empirical tariff-evasion application,
followed by Gaussian-versus-Epanechnikov sensitivity in the example. This new
scope supersedes the prior decision to leave only a simulated failure draft.
The completed simulation and earlier empirical investigation remain frozen.

1. Reconstruct the authors' deterministic application sample (1,084 observations;
   cell counts 120/56/824/84; 131 four-digit HS clusters). Recompute the published
   composition-robust ATT and uncertainty for all four outcomes from their
   archived paper-final nuisance fits. Check ATT/IID SE/clustered multiplier SE
   against Table 4's retained precision. This is saved-nuisance reproduction;
   it is not presented as a successful rerun of historical propensity CV.
2. Hold the sample, covariate definitions, normalized ATT score and each outcome's
   archived propensity array fixed. Fit np local-linear outcome regressions
   separately in the three comparison cells, first Epanechnikov and then Gaussian.
   Re-select bandwidths by CV-LS within each kernel, nmulti=2, with the same
   per-outcome/cell seed 851000+100*outcome+cell. Use unordered Li–Racine kernels
   for all nine categorical covariates. Keep categorical levels from the full
   deterministic sample; do not change their definitions to force completion.
   Use external npreg predictions in treated/post rows and npreghat LOO predictions
   in the corresponding training cell. No response clipping or probability
   renormalization is added. Retain the paper's archived propensity truncation.
3. Run exactly eight outcome/kernel jobs (four outcomes times two kernels),
   retaining intermediate bandwidths and predictions even if scoring fails.
   M2MBP owns jobs 1–4, pc-racine1 jobs 5–8; four workers each, nice 20, one math
   thread, 1,800-second cap per job. Reuse the exact private np/compdid installations
   from the completed published-design run, with the frozen tarballs retained
   here for independent setup. Reserve local compute for coordination and the
   concurrent package work. All paths stay under /Users/jracine/Development on
   every host. Do not rerun rejected old propensity candidates, retry a failed
   kernel, change solver policy, or add another Monte Carlo campaign.
4. Recompute cluster multiplier uncertainty using 9,999 Mammen draws and seed
   1234, with identical draws for all arms of each outcome. Report point estimates,
   IID and clustered SEs, kernel differences, failures, and the difference relative
   to the published estimate. Show cluster concentration as a relevant inference
   limitation, without making this example contingent on an exhaustive audit.
   Declare that re-tuning and the different outcome-bandwidth parameterization
   are part of the practical sensitivity comparison.
5. Produce a readable, executable empirical example and rendered HTML companion.
   Lead with the paper replication, then show both kernels side by side. An
   undefined result remains visible; Gaussian is not a silent fallback. Keep
   causal interpretation conditional on the paper's identifying assumptions.
   Explicitly disclose the historical categorical-kernel discrepancy, reuse of
   saved propensity fits, and that previous from-scratch corrected propensity
   searches did not converge. No claim that the new exercise fixes those searches.
   No production-package edits, live Gallery publication or Git push.

Sources: https://psantanna.com/files/DiD_CC.pdf (Section 6, Table 4), the author's
frozen compdid replication vignette, and the retained provenance in inputs/.
