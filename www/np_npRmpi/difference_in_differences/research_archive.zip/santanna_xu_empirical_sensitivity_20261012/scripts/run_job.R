args<-commandArgs(TRUE);id<-as.integer(args[1]);stopifnot(id %in% 1:8)
source('R/application.R')
i<-(id+1L)%/%2L;kernel<-c('epanechnikov','gaussian')[(id-1L)%%2L+1L]
dest<-sprintf('results/fits/%02d.rds',id);stopifnot(!file.exists(dest))
z<-fit_application(i,kernel);z$id<-id
saveRDS(z,paste0(dest,'.partial'));stopifnot(file.rename(paste0(dest,'.partial'),dest))
cat('JOB_RECORDED',id,'status',z$ok,'error',z$error,'\n')
