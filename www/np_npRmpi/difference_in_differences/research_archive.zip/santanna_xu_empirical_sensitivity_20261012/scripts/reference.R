source('R/load.R')
set.seed(ref$locpol$seed);rows<-list();tests<-list();fits<-list()
for(i in 1:4) {
 y<-dat[[ref$locpol$ynames[i]]];ps<-ref$locpol$ps_fit[[i]]$fitted.values;mu<-ref$locpol$or_fit[[i]]$fitted.values
 ns<-compdid::drdid_nonstationary(y,d,post,ps,mu);st<-compdid::drdid_stationary(y,d,post,ps,mu)
 independent<-sx_score(y,d,post,ps,mu)
 stopifnot(max(abs(c(independent$att-ns$ATT,independent$se-ns$se,independent$influence-ns$att.inf.func)))<1e-9)
 cb<-compdid::drdid_cluster_bootstrap(ns,st,cluster,nboot=ref$locpol$nboot,seed=NULL,keep_boots=FALSE)
 fits[[i]]<-list(nonstationary=ns,stationary=st,independent=independent,clustered=cb)
 for(type in c('tau_sz','tau_dr')) {
   b<-if(type=='tau_dr')ns else st;cse<-if(type=='tau_dr')cb$nonstationary$se else cb$stationary$se
   published<-ref$table4[grepl(type,ref$table4$estimator) & ref$table4$outcome==ref$table4$outcome[i],]
   diff<-max(abs(c(b$ATT-published$estimate,b$se-published$se,cse-published$cluster_se)))
   stopifnot(diff<1e-10)
   rows[[length(rows)+1L]]<-data.frame(outcome_index=i,outcome=ref$locpol$ynames[i],label=ref$table4$outcome[i],
       estimator=type,ATT=b$ATT,iid_se=b$se,cluster_se=cse,maximum_reference_difference=diff)
 }
 tests[[i]]<-data.frame(outcome=ref$locpol$ynames[i],wald=cb$stationarity_test$statistic,
  iid_p=cb$stationarity_test$p.value,cluster_p=cb$stationarity_test$clustered.p.value)
 stopifnot(max(abs(unlist(tests[[i]][,2:4])-as.numeric(ref$tests[i,c('wald_stat','unclustered_p_value','clustered_p_value')])))<1e-10)
}
write.csv(do.call(rbind,rows),'results/paper_replication.csv',row.names=FALSE)
write.csv(do.call(rbind,tests),'results/paper_tests.csv',row.names=FALSE)
saveRDS(fits,'results/paper_replication.rds');print(do.call(rbind,rows));cat('PAPER_REPLICATION_PASS\n')
