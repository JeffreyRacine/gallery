source('R/load.R')
checks<-list();scores<-list()
for(id in 1:8) {
 z<-readRDS(sprintf('results/fixed/%02d.rds',id));stopifnot(z$ok)
 mu<-z$audit$mu;mu[is.na(mu)]<-0
 a<-compdid::drdid_nonstationary(z$y,z$d,z$post,z$ps,mu)
 err<-max(abs(c(z$score$att-a$ATT,z$score$se-a$se,z$score$influence-a$att.inf.func)))
 stopifnot(err<1e-9);scores[[id]]<-data.frame(id=id,difference=err)
 for(cell in 2:4) {
  f<-z$audit$outcomes[[cell]];tr<-f$training;cn<-as.matrix(z$x[,1:2]);b<-f$bw$bw
  for(i in c(head(tr,3),head(f$evaluation,3))) {
   dx<-sweep(cn[tr,,drop=FALSE],2,cn[i,],'-');u<-sweep(dx,2,b[1:2],'/')
   w<-if(z$kernel=='gaussian')apply(dnorm(u),1,prod) else apply(pmax(1-u^2/5,0),1,prod)
   for(j in 3:ncol(z$x))w<-w*ifelse(z$x[tr,j]==z$x[i,j],1,b[j])
   w[tr==i]<-0;X<-cbind(1,dx)
   full<-sum(w>0)>=3 && qr(X[w>0,,drop=FALSE])$rank==3
   condition<-if(full)kappa(crossprod(X,X*w)) else Inf
   if(full && condition<1e7) {
    expected<-lm.wfit(X,z$y[tr],w,tol=1e-12)$coefficients[1]
    delta<-abs(expected-z$audit$mu[i,cell]);stopifnot(delta<1e-8)
   } else delta<-NA_real_
   checks[[length(checks)+1L]]<-data.frame(id=id,cell=cell,row=i,full_rank=full,condition=condition,difference=delta)
  }
 }
}
write.csv(do.call(rbind,checks),'results/fixed_prediction_checks.csv',row.names=FALSE)
write.csv(do.call(rbind,scores),'results/fixed_score_checks.csv',row.names=FALSE)
cat('FIXED_CHECK_PASS: independent full-rank QR and author score; no fitting controls changed.\n')
