#!/bin/bash
set -u
cd /Users/jracine/Development/lpdensity/npreg_causal_feasibility_20261011/santanna_xu_empirical_sensitivity_20261012 || exit 1
export TMPDIR="$PWD/tmp"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
nice -n 20 /opt/local/bin/python3 scripts/controller.py "$1" "$2" "$3" > "logs/controller_${1}_${2}.log" 2>&1
echo "$?" > "logs/controller_${1}_${2}.status"
