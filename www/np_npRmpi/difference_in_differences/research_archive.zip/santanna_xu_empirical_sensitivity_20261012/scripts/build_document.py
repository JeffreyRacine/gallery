from pathlib import Path
import csv
r=Path(__file__).resolve().parent.parent
rows=list(csv.DictReader((r/'results/comparison.csv').open()))
by={(x['outcome'],x['arm']):x for x in rows}
outcomes=['bp','lba','lba_value','lba_tonnage']
labels=['Bribe probability','Log(1 + bribe)','Log(1 + bribe / shipment value)','Log(1 + bribe / shipment tonnage)']
def table(headers,body):
 return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(row)+' |\n' for row in body)
def cell(z):return f"{float(z['ATT']):.4f} ({float(z['cluster_se']):.4f})"
main=table(['Outcome','Paper, saved nuisances','np Epanechnikov','np Gaussian'],[[lab]+[cell(by[o,a]) for a in ['paper','fixed_epanechnikov','fixed_gaussian']] for o,lab in zip(outcomes,labels)])
diff=list(csv.DictReader((r/'results/kernel_differences.csv').open()))
pairs=table(['Outcome','Gaussian − Epanechnikov','Paired clustered SE'],[[lab]+[f"{float(z[k]):.6f}" for k in ['gaussian_minus_epanechnikov','paired_cluster_se']] for lab,z in zip(labels,[z for z in diff if z['mode']=='fixed'])])
retuned=table(['Outcome','Re-tuned Epanechnikov','Re-tuned Gaussian ATT (SE)'],[[lab,'Failed: invalid search objective' if o in ['bp','lba_tonnage'] else 'Failed: undefined required prediction',cell(by[o,'retuned_gaussian'])] for o,lab in zip(outcomes,labels)])
rep=list(csv.DictReader((r/'results/paper_replication.csv').open()))
replication=table(['Outcome','Stationary DR ATT (SE)','Composition-robust DR ATT (SE)'],[[lab]+[cell(next(z for z in rep if z['outcome']==o and z['estimator']==a)) for a in ['tau_sz','tau_dr']] for o,lab in zip(outcomes,labels)])
body='''This example combines computational reproduction of the authors' saved-fit calculations with a same-data implementation comparison using fresh `np` outcome regressions and an independently coded ATT score. Success for the implementation comparison means quantitatively and qualitatively comparable interpretations; exact equality is not the criterion. At the published outcome-bandwidth scale, the two kernels give similar effects. Independent re-selection of eleven bandwidths in each comparison cell is substantially less stable; those results are included below.

The exercise has three distinct parts: reproduce the published DR rows from the authors' saved nuisance fits; replace only the outcome regressions at published bandwidths; and disclose an earlier, separately re-tuned sensitivity arm. It does **not** claim to have successfully re-estimated the paper's propensity fits from scratch.

## Published application and numerical reproduction

[Sant'Anna and Xu, Section 6 and Table 4](https://psantanna.com/files/DiD_CC.pdf) apply composition-robust difference-in-differences to Sequeira's tariff-and-bribes data. We follow their archived application sample and controls. There are 1,084 complete observations, with treated/post, treated/pre, untreated/post and untreated/pre counts of 120, 56, 824 and 84, and 131 four-digit HS clusters.

Using the saved author outcome and propensity arrays, we reproduce both DR estimators, their IID and clustered standard errors, and the stationarity tests to numerical precision. This follows the author's [saved-fit reproduction vignette](../inputs/author_replication_vignette.Rmd). The reproduction here concerns the DR rows; TWFE is outside this calculation.

'''+replication+'''
Parentheses contain clustered standard errors. The largest absolute difference in these estimates and standard errors from the archived reference is 3.1 × 10⁻¹⁴. The unrounded results and stationarity tests are retained in `results/paper_replication.csv` and `results/paper_tests.csv`.

## Outcome-kernel sensitivity at published bandwidths

We hold the observations, covariate definitions, normalized ATT score and each outcome's archived propensity array fixed. The propensity values retain the historical 0.01 truncation; no extra normalization or clipping is added. This is an outcome-kernel comparison, not a comparison of complete propensity-learning procedures.

For each outcome, the two continuous covariates are normalized to [0,1]. The nine categorical controls are unordered factors. All three comparison cells use the published shared continuous bandwidth h and categorical bandwidth λ. In `np`, both continuous bandwidths are h/√5 for both kernels: `np` uses a variance-one Epanechnikov parameterization, so this corresponds to the paper's Epanechnikov half-width h and matches the Gaussian smoothing variance. The h values are approximately 1.0994, 1.0211, 1.1236 and 0.6954; λ values are 0.8766, 0.8766, 0.8371 and 0.8681. They are taken directly from the saved reference, without a new search.

```r
published <- as.numeric(ref$locpol$or_fit[[i]]$bws)
bandwidths <- c(rep(published[1] / sqrt(5), 2), rep(published[2], 9))
b <- npregbw(xdat=x[tr, , drop=FALSE], ydat=y[tr],
             bws=bandwidths, bandwidth.compute=FALSE,
             regtype="ll", ckertype=kernel, ukertype="liracine")
external <- fitted(npreg(bws=b, txdat=x[tr, , drop=FALSE], tydat=y[tr],
                        exdat=x[te, , drop=FALSE], se=FALSE))
loo <- npreghat(bws=b, txdat=x[tr, , drop=FALSE], y=y[tr],
               leave.one.out=TRUE, output="apply")
```

Here `tr` selects one comparison cell and `te` selects treated/post observations. External predictions are needed in treated/post rows, and leave-one-out predictions in the corresponding training cell. The treated/post outcome regression cancels from this ATT, so only the three comparison regressions are fitted. `R/fixed_application.R` implements the complete calculation and `inputs/core_score_aware.R` evaluates the normalized score.

'''+main+'''
All eight fixed-bandwidth fits completed. Parentheses again contain clustered standard errors. Both kernels preserve the negative direction for all four outcomes. The probability and log-bribe estimates are particularly close to the paper. The shipment-value effect is about 35% smaller in magnitude and the tonnage effect about 39–44% larger. These are meaningful magnitude differences even though they are less than one published clustered SE; the latter comparison is a descriptive scale, not an equivalence test. Using normal 95% critical values with the reported clustered SEs, the tonnage interval includes zero for the paper and excludes zero for both `np` kernels. The same-data comparison therefore supports the same direction of the effect with stronger statistical evidence for tonnage, rather than identical significance decisions.

![Composition-robust ATT at published outcome bandwidths. These are point estimates; standard errors appear in the table.](../figures/empirical_kernels.png)

'''+pairs+'''
For uncertainty, we use the paper's influence-function cluster multiplier calculation: 9,999 Mammen draws, seed 1234, and bootstrap IQR divided by the standard-normal IQR. Each outcome uses identical draws across arms, and differences use the difference of the two influence functions. Nuisances are not refitted in these multiplier draws. The small paired differences provide a descriptive sensitivity check; this is not a formal demonstration of kernel equivalence.

The comparisons between the two `np` kernels hold the unordered Li–Racine equality/mismatch weights fixed. Differences from the archived paper results also reflect implementation differences: the historical unordered kernel used distances between numeric category labels, and locally singular fits can invoke different numerical rules. The new example uses standard unordered weighting. Neither attribution of the entire paper–`np` difference to kernel shape nor exact historical estimator equivalence is claimed.

## What happened when bandwidths were re-selected?

The original plan separately selected eleven bandwidths in each comparison cell by CV-LS, with two starts and paired seeds across kernels. This is considerably more flexible than the paper's shared two-bandwidth specification. All eight planned jobs were retained, including failures.

'''+retuned+'''
The two undefined Epanechnikov scores have recorded all-zero kernel-weight warnings at required external predictions. The other two Epanechnikov jobs stopped with an invalid-raw-objective search error; we have not established that these optimizer errors have the same geometric cause. They are not timeouts or R-session crashes. Gaussian completed every job but gave implausible extrapolation for some regressions: one local-linear prediction for the binary bribe outcome was about −289. The resulting probability ATT of −4.756 is outside the feasible population effect range. Completing a calculation therefore does not establish that its nuisance fits are well behaved.

After observing those results, we declared a separate [fixed-bandwidth addendum](../FIXED_BANDWIDTH_ADDENDUM.md) before computing the eight published-bandwidth fits. That comparison uses external, already published bandwidths; it does not retry or replace any failed re-tuned result. No fitted response was clipped, no optimizer rule changed, and Gaussian was never silently substituted for Epanechnikov.

## Scope of the example

This is a successful bounded attempt at the requested same-data comparison: the implementations give broadly comparable quantitative and qualitative interpretations at the paper's smoothing scale, and kernel-shape sensitivity is small. The effect-size and tonnage-inference differences above remain part of that assessment. It does not support advertising independently tuned Gaussian or Epanechnikov as a robust automatic default for these sparse cells. Earlier corrected from-scratch propensity searches all returned convergence code 10; that limitation remains.

The causal interpretation remains conditional on the paper's identification and adjustment assumptions. This numerical exercise does not establish the validity or timing of every control. Clusters are highly uneven: the largest contains 550 observations, or 50.7% of the sample. The reported clustered uncertainty is a reproduction of the specified procedure, not an independent guarantee of reliable finite-sample inference.

## Reproduce and inspect

From the study root, the following base-R command re-evaluates the score and clustered uncertainty from the retained fits and verifies all twelve paper/kernel rows:

```bash
Rscript --vanilla example/empirical_example.R --from-receipts
```

To repeat the eight fixed-bandwidth outcome fits, first install the retained source archives into the study's private library and then run the executable example. On the recorded macOS setup:

```bash
bash scripts/setup.sh
TMPDIR="$PWD/tmp" OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \\
MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \\
nice -n 20 Rscript --vanilla example/empirical_example.R --refit
```

The script writes a new timestamped directory below `example/reproduced/`; it never overwrites the original receipts. The fixed fitting helper was executed for all eight specifications. The example's retained-results mode was executed and checked; its optional refit wrapper was not launched a second time merely to duplicate those fits.

The frozen environment uses `np` 0.80-1, the narrowly corrected research `compdid` 0.1.0 and the retained source archives. It does not depend on current production checkout contents. `inputs/author_provenance.json`, `inputs/tarball_sha256.json`, and `FINAL_SHA256.json` bind the source and results. The saved-author replication, normalized score, and 144 full-rank local predictions have independent numerical checks. This is focused example verification, not package release qualification.
'''
qmd='''---
title: "Tariff reductions and bribes"
subtitle: "Reproduction and a same-data implementation comparison"
date: "2026-10-12"
format:
  html:
    embed-resources: true
    toc: true
    toc-depth: 2
    theme: cosmo
    code-copy: true
execute:
  enabled: false
---

'''+body
(r/'example/empirical_example.qmd').write_text(qmd)
report='''# Empirical reproduction and implementation comparison: completed

October 12, 2026. The bounded comparison supports a successful same-data implementation example at the published smoothing scale. The saved-fit stage is computational reproduction; fresh np outcome regressions and the independently coded ATT score constitute a same-data implementation comparison with shared archived propensities. Quantitative and qualitative comparability is its success criterion. The published DR calculations reproduce to numerical precision, and the two np kernels give similar results. Independently re-tuned outcome fits remain unstable and are prominently disclosed. See the [terminology clarification](TERMINOLOGY.md).

The [rendered example](example/empirical_example.html), [Quarto source](example/empirical_example.qmd), and [executable R example](example/empirical_example.R) contain the method, results, limitations and reproduction commands. The [plan](PLAN.md) and [pre-fit addendum](FIXED_BANDWIDTH_ADDENDUM.md) preserve the sequence of decisions.

## Main results

Composition-robust ATT, with clustered multiplier SE in parentheses; archived propensity arrays are shared and continuous smoothing variance is matched at published outcome bandwidths.

'''+main+'''
The first two outcomes are quantitatively close to the published effects. Shipment-value and tonnage magnitudes differ materially, but the two np kernels remain close. The criterion is quantitative and qualitative comparability, not numerical equality. All four effect directions agree and kernel sensitivity is small. Normal 95% clustered intervals for tonnage exclude zero in the np arms but include zero for the published calculation, so statistical evidence for this outcome is stronger with np. This is a disclosed inferential difference within the broadly comparable substantive pattern.

## Retained re-tuned comparison

'''+retuned+'''
All eight processes exited zero and none timed out; four statistical fits succeeded and four failed. Two Epanechnikov failures have explicit zero-weight prediction warnings. The two invalid-raw-objective failures remain a separate search-failure class, without an asserted geometric root cause. Gaussian completion did not ensure stable extrapolation. No fallback, response clipping, retries, relaxed tolerance, production repair or new propensity search was introduced.

## Verification and provenance

- Both published DR rows, IID and clustered SEs, and stationarity tests reproduce at the saved nuisances. Maximum ATT/SE discrepancy: 3.1e-14.
- All eight fixed-bandwidth fits succeeded in one additional calculation, raw process exit zero. Independent author-score/influence checks differ by at most 2.2e-12. All 144 selected full-rank weighted-QR prediction checks passed, maximum difference 4.0e-13; this is a focused sample, not every prediction.
- The base-R example re-evaluates all twelve paper/fixed-kernel ATT and uncertainty rows within 1e-10. Shared propensity arrays and sample row identities are verified.
- The eight re-tuned jobs ran on M2MBP (1–4) and pc-racine1 (5–8); the fixed comparison ran on pc-racine1. Controller settings were four workers per host, nice 20, one math thread, and 1,800 seconds per re-tuned job. Jobs finished before a live worker-count observation; configured parallelism is not presented as an independently observed live count. The fixed calculation completed well below the declared 300-second administrative cap; that run did not have an enforced watchdog.
- Exact remote/local fit, failure, process and job-log hashes match (12 files on M2MBP, 20 on pc-racine1); frozen execution sources are unchanged and owned remote processes are absent at closeout. See `inputs/remote_closeout_*.json`.
- Earlier full propensity searches remain rejected with code 10. The archived categorical-kernel discrepancy and local singular-fit differences remain disclosed. Both new kernel arms use standard unordered Li–Racine weights.
- The largest cluster contains 50.7% of observations. Inference is the specified influence-function multiplier procedure, without nuisance refitting; no new finite-sample inference or causal-identification guarantee is asserted.

`results/` retains all 8 re-tuned and 8 fixed fit objects, raw exit receipts, paper reproduction, common-multiplier summaries, failures/warnings, bandwidths, prediction ranges and independent checks. `inputs/execution_sha256.json` binds the original pre-run sources; the later fixed comparison and documents are separately bound by `FINAL_SHA256.json`. Final local preservation checks are recorded in `inputs/closeout.json`.

No production package or Gallery file was edited by this work, and nothing was pushed or published. The frozen preceding study is checked separately; concurrent package/release work is recorded rather than reset. No additional numerical campaign is required to present this qualified example honestly.
'''
(r/'REPORT.md').write_text(report)
print('Wrote example and report from retained CSV tables.')
