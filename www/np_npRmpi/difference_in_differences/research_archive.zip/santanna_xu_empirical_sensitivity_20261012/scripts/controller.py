"""Fixed disjoint host ranges; explicit child timeout; immutable per-attempt receipts."""
from pathlib import Path
import concurrent.futures, datetime, hashlib, json, os, subprocess, sys, time

root=Path(__file__).resolve().parent.parent
os.chdir(root)
first,last,workers=map(int,sys.argv[1:4])
assert (first,last,workers) in ((1,4,4),(5,8,4))
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[name]='1'
os.environ['TMPDIR']=str(root/'tmp')
os.environ['R_LIBS']=str(root/'reproduction_artifacts/Rlib')
for relative,wanted in json.loads((root/'inputs/execution_sha256.json').read_text()).items():
    assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==wanted, relative
out=root/'results'
for directory in ('fits','process','logs'):(out/directory).mkdir(parents=True,exist_ok=True)

def one(i):
    receipt=out/'process'/f'{i:04d}.json'
    assert not receipt.exists() and not (out/'fits'/f'{i:02d}.rds').exists(), f'Duplicate attempt {i}'
    start=time.time()
    cmd=['/Library/Frameworks/R.framework/Resources/bin/Rscript','--vanilla',str(root/'scripts/run_job.R'),str(i)]
    timedout=False
    with (out/'logs'/f'{i:04d}.log').open('w') as log:
        child=subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy())
        try: code=child.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            timedout=True;child.kill();code=child.wait()
    info={'id':i,'host':os.uname().nodename,'returncode':code,
          'timedout':timedout,'pid':child.pid,'elapsed':time.time()-start,
          'receipt_present':(out/'fits'/f'{i:02d}.rds').exists(),
          'started_utc':datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat()}
    tmp=receipt.with_suffix('.partial');tmp.write_text(json.dumps(info,indent=2)+'\n');tmp.rename(receipt)
    return info

with (out/f'controller_{first}_{last}.jsonl').open('x') as log:
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(one,i):i for i in range(first,last+1)}
        for j,f in enumerate(concurrent.futures.as_completed(futures),1):
            info=f.result();log.write(json.dumps(info)+'\n');log.flush()
            print(datetime.datetime.now().isoformat(),f'completed={j}/{last-first+1}',
                  f'id={info["id"]} code={info["returncode"]} timeout={info["timedout"]}',flush=True)
print('OWNED_RANGE_COMPLETE',first,last,flush=True)
