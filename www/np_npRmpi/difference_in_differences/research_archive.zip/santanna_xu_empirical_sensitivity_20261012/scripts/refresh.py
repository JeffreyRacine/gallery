from pathlib import Path
import concurrent.futures, datetime, json, subprocess, time, sys
root=Path(__file__).resolve().parent.parent
hosts=[('M2MBP','jracine@M2MBP.local','ssh -4 -o ConnectTimeout=60'),('pc-racine1','jracine@pc-racine1.mcmaster.ca','ssh -o ConnectTimeout=60')]
def pull(h):
    label,host,ssh=h
    for folder in ('results','logs'):
        dest=root/folder/label if folder=='logs' else root/folder
        dest.mkdir(exist_ok=True)
        subprocess.run(['rsync','-az','--exclude=*.partial','-e',ssh,host+':'+str(root/folder)+'/',str(dest)+'/'],check=True,timeout=90)
def refresh():
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(pull,hosts))
    receipts=[json.loads(p.read_text()) for p in (root/'results/process').glob('*.json')]
    progress={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed':len(receipts),
              'expected':8,'raw_zero':sum(r['returncode']==0 for r in receipts),'timeouts':sum(r['timedout'] for r in receipts)}
    (root/'PROGRESS.json').write_text(json.dumps(progress,indent=2)+'\n');print(progress,flush=True)
    return len(receipts)==8
for k in range(60 if '--monitor' in sys.argv else 1):
    try:
        if refresh():break
    except Exception as exc:print(type(exc).__name__,str(exc),flush=True)
    if '--monitor' in sys.argv:time.sleep(60)
