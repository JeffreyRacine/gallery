# Base-R analysis: frozen propensity arrays, common cluster multiplier draws.
source('R/data.R')
paper<-readRDS('results/paper_replication.rds')
retuned<-lapply(sprintf('results/fits/%02d.rds',1:8),readRDS)
fixed<-lapply(sprintf('results/fixed/%02d.rds',1:8),readRDS)
stopifnot(identical(vapply(retuned,`[[`,integer(1),'id'),1:8),identical(vapply(fixed,`[[`,integer(1),'id'),1:8))
g<-as.integer(factor(cluster));G<-max(g);n<-nrow(dat);B<-ref$locpol$nboot
sizes<-table(cluster)
write.csv(data.frame(n=n,clusters=G,largest_cluster_size=max(sizes),largest_cluster_share=max(sizes)/n),
 'results/design.csv',row.names=FALSE)
rows<-list();differences<-list();warnings<-list();bandwidths<-list();prediction_ranges<-list()
set.seed(ref$locpol$seed)
for(i in 1:4) {
 lo<-(1-sqrt(5))/2;hi<-(1+sqrt(5))/2
 multipliers<-matrix(ifelse(rbinom(G*B,1,hi/sqrt(5))==1,lo,hi),G,B)
 cluster_stats<-function(s) {
  sums<-drop(rowsum(s$influence,g,reorder=TRUE));draws<-drop(crossprod(sums,multipliers))/n
  list(se=IQR(draws)/(qnorm(.75)-qnorm(.25)),largest_share=max(sums^2)/sum(sums^2),draws=draws)
 }
 p<-paper[[i]]$independent;pc<-cluster_stats(p)
 stopifnot(abs(pc$se-paper[[i]]$clustered$nonstationary$se)<1e-10)
 arms<-list(paper=list(ok=TRUE,score=p,error='',audit=list(warnings=character()),elapsed=0))
 for(mode in c('fixed','retuned'))for(kernel in c('epanechnikov','gaussian')) {
  id<-2*i-if(kernel=='epanechnikov')1L else 0L
  z<-if(mode=='fixed')fixed[[id]] else retuned[[id]]
  stopifnot(identical(z$ps,ref$locpol$ps_fit[[i]]$fitted.values),identical(z$row_ids,rownames(dat)))
  arms[[paste(mode,kernel,sep='_')]]<-z
 }
 for(arm in names(arms)) {
  z<-arms[[arm]];s<-z$score;c<-if(z$ok)cluster_stats(s) else NULL
  rows[[length(rows)+1L]]<-data.frame(outcome_index=i,outcome=ref$locpol$ynames[i],label=ref$table4$outcome[i],
   arm=arm,ok=z$ok,error=z$error,ATT=if(z$ok)s$att else NA_real_,iid_se=if(z$ok)s$se else NA_real_,
   cluster_se=if(z$ok)c$se else NA_real_,largest_cluster_variance_share=if(z$ok)c$largest_share else NA_real_,
   difference_from_paper=if(z$ok)s$att-p$att else NA_real_,
   difference_in_paper_cluster_se=if(z$ok)(s$att-p$att)/pc$se else NA_real_,elapsed=z$elapsed)
  if(length(z$audit$warnings))warnings[[length(warnings)+1L]]<-data.frame(outcome=ref$locpol$ynames[i],arm=arm,warning=z$audit$warnings)
  if(arm!='paper')for(cell in 2:4) {
   f<-z$audit$outcomes[[cell]];if(is.null(f))next
   b<-f$bw
   bandwidths[[length(bandwidths)+1L]]<-data.frame(outcome=ref$locpol$ynames[i],arm=arm,cell=cell,
    variable=names(z$x),bandwidth=b$bw,kernel=b$ckertype)
   values<-c(f$external,f$loo)
   prediction_ranges[[length(prediction_ranges)+1L]]<-data.frame(outcome=ref$locpol$ynames[i],arm=arm,cell=cell,
    minimum=min(values,na.rm=TRUE),maximum=max(values,na.rm=TRUE),undefined=sum(!is.finite(values)))
  }
 }
 for(mode in c('fixed','retuned')) {
  e<-arms[[paste0(mode,'_epanechnikov')]];a<-arms[[paste0(mode,'_gaussian')]];ok<-e$ok && a$ok
  ds<-if(ok)list(influence=a$score$influence-e$score$influence) else NULL
  differences[[length(differences)+1L]]<-data.frame(outcome=ref$locpol$ynames[i],mode=mode,paired=ok,
    gaussian_minus_epanechnikov=if(ok)a$score$att-e$score$att else NA_real_,
    paired_cluster_se=if(ok)cluster_stats(ds)$se else NA_real_)
 }
}
out<-do.call(rbind,rows);write.csv(out,'results/comparison.csv',row.names=FALSE)
write.csv(do.call(rbind,differences),'results/kernel_differences.csv',row.names=FALSE)
write.csv(do.call(rbind,warnings),'results/warnings.csv',row.names=FALSE)
write.csv(do.call(rbind,bandwidths),'results/bandwidths.csv',row.names=FALSE)
write.csv(do.call(rbind,prediction_ranges),'results/prediction_ranges.csv',row.names=FALSE)
print(out[,c('outcome','arm','ok','ATT','cluster_se')],row.names=FALSE)
print(do.call(rbind,differences),row.names=FALSE)
draw<-function() {
 par(mfrow=c(2,2),mar=c(4.5,4.7,2.8,.6),las=1)
 colors<-c('#656B73','#CE7B28','#168393')
 for(i in 1:4) {
  a<-out[out$outcome_index==i & out$arm %in% c('paper','fixed_epanechnikov','fixed_gaussian'),]
  span<-range(c(0,a$ATT));padding<-max(diff(span)*.13,.005)
  plot(1:3,a$ATT,pch=19,col=colors,cex=1.2,xaxt='n',xlab='',ylab='ATT',xlim=c(.5,3.5),
    ylim=span+c(-padding,padding),main=a$label[1],cex.main=.95)
  axis(1,1:3,c('Paper','np\nEpanechnikov','np\nGaussian'),cex.axis=.86)
  abline(h=0,lty=3,col='gray70');lines(1:3,a$ATT,col='gray75')
  points(1:3,a$ATT,pch=19,col=colors,cex=1.2)
 }
}
png('figures/empirical_kernels.png',width=1500,height=1050,res=160);draw();dev.off()
pdf('figures/empirical_kernels.pdf',width=9.4,height=6.6);draw();dev.off()
cat('ANALYSIS_PASS: 8 retuned and 8 fixed specifications retained; shared propensity identities verified.\n')
