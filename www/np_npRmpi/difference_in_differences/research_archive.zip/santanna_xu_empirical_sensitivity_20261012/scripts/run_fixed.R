source('R/fixed_application.R')
dir.create('results/fixed',showWarnings=FALSE)
for(id in 1:8) {
 i<-(id+1L)%/%2L;kernel<-c('epanechnikov','gaussian')[(id-1L)%%2L+1L]
 dest<-sprintf('results/fixed/%02d.rds',id);stopifnot(!file.exists(dest))
 z<-fit_fixed_application(i,kernel);z$id<-id;saveRDS(z,paste0(dest,'.partial'))
 stopifnot(file.rename(paste0(dest,'.partial'),dest))
 cat('FIXED_RECORDED',id,z$ok,z$score$att,z$error,'\n')
}
