from pathlib import Path
import datetime, hashlib, json, os, subprocess
r = Path(__file__).resolve().parent.parent
hashes = {str(p.relative_to(r)): hashlib.sha256(p.read_bytes()).hexdigest()
          for folder in ('results/fits','results/fixed','results/process','results/logs')
          for p in (r/folder).glob('*') if p.is_file()}
frozen = json.loads((r/'inputs/execution_sha256.json').read_text())
changed = [p for p,h in frozen.items() if hashlib.sha256((r/p).read_bytes()).hexdigest()!=h]
processes = subprocess.check_output(['ps','-axo','pid,ppid,ni,etime,command'],text=True).splitlines()
owned = [s for s in processes if (str(r)+'/scripts/run_job.R' in s or
         s.rstrip().endswith('scripts/controller.py 1 4 4') or
         s.rstrip().endswith('scripts/controller.py 5 8 4') or
         s.rstrip().endswith('Rscript --vanilla scripts/run_fixed.R') or
         'sx-empirical' in s) and 'receipt_snapshot' not in s]
status = {p.name:p.read_text().strip() for p in (r/'logs').glob('*.status')}
print(json.dumps({'host':os.uname().nodename,
                  'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'hashes':hashes,'changed_execution_files':changed,
                  'owned_processes':owned,'status':status},indent=2))
