#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p tmp logs reproduction_artifacts/Rlib
export TMPDIR="$PWD/tmp" R_LIBS="$PWD/reproduction_artifacts/Rlib"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
for archive in roptim_0.1.7.tar.gz np_0.80-1.tar.gz compdid_corrected_0.1.0.tar.gz; do
 /Library/Frameworks/R.framework/Resources/bin/R CMD INSTALL --library=reproduction_artifacts/Rlib "reproduction_artifacts/tarballs/$archive"
done
/Library/Frameworks/R.framework/Resources/bin/Rscript --vanilla -e '.libPaths(c("reproduction_artifacts/Rlib",.libPaths()));library(np);library(compdid);sessionInfo();cat(find.package("np"),find.package("compdid"),"\n")'
