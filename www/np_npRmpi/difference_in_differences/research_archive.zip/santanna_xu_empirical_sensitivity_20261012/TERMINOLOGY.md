# Interpretation and terminology clarification

Jeffrey clarified the success criterion during closeout on October 12, 2026.
Reproduction uses the original data, code and methods to recover the published
numbers. Replication ordinarily concerns an independent study, often using new
data. This exercise combines computational reproduction with a same-data
implementation comparison. Quantitatively and qualitatively comparable
interpretations constitute a successful attempt; exact equality is not required
of the different implementation.

Here the saved-author stage is reproduction. Fresh np outcome regressions and an
independently coded ATT score provide the implementation comparison, while the
propensity arrays remain the authors' archived fits. It is therefore neither a
new-data replication nor a wholly independent nuisance re-estimation. The final
example and report use this distinction and retain the actual effect-size and
inferential differences. Earlier plans and pre-run source hashes remain frozen
as chronological records, including their earlier terminology.
