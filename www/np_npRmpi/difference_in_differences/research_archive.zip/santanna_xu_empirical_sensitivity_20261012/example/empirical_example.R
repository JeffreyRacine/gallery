# Run from the study root. Base R suffices to inspect the retained calculation:
#   Rscript --vanilla example/empirical_example.R --from-receipts
# To repeat the eight fixed-bandwidth fits with the retained private packages:
#   bash scripts/setup.sh
#   Rscript --vanilla example/empirical_example.R --refit
# --refit writes a new directory and never replaces the research receipts.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==1L, args %in% c('--from-receipts','--refit'))
refit <- args=='--refit'
if(refit) source('R/fixed_application.R') else source('R/data.R')
if(refit) {
  destination <- file.path('example','reproduced',format(Sys.time(),'%Y%m%dT%H%M%S'))
  stopifnot(!dir.exists(destination))
  dir.create(destination,recursive=TRUE)
}

# The normalized composition-robust ATT uses only three comparison-cell
# outcome regressions. Their training predictions are leave-one-out; their
# predictions in the treated/post cell are external predictions.
g <- as.integer(factor(cluster)); G <- max(g); n <- nrow(dat)
set.seed(ref$locpol$seed)
lo <- (1-sqrt(5))/2; hi <- (1+sqrt(5))/2
multiplier_sets <- lapply(1:4,function(i)
  matrix(ifelse(rbinom(G*ref$locpol$nboot,1,hi/sqrt(5))==1,lo,hi),G))
answer <- list()
for(i in 1:4) {
  mult <- multiplier_sets[[i]]
  clustered_se <- function(influence) {
    sums <- drop(rowsum(influence,g,reorder=TRUE))
    draws <- drop(crossprod(sums,mult))/n
    IQR(draws)/(qnorm(.75)-qnorm(.25))
  }
  y <- dat[[ref$locpol$ynames[i]]]
  ps <- ref$locpol$ps_fit[[i]]$fitted.values
  paper <- sx_score(y,d,post,ps,ref$locpol$or_fit[[i]]$fitted.values)
  for(arm in c('paper','epanechnikov','gaussian')) {
    if(arm=='paper') s <- paper else {
      id <- 2L*i-if(arm=='epanechnikov')1L else 0L
      z <- if(refit) fit_fixed_application(i,arm) else
        readRDS(sprintf('results/fixed/%02d.rds',id))
      if(refit) saveRDS(z,file.path(destination,sprintf('%02d.rds',id)))
      if(!z$ok) stop(z$error)
      stopifnot(identical(z$ps,ps),identical(z$row_ids,rownames(dat)))
      s <- sx_score(z$y,z$d,z$post,z$ps,z$audit$mu)
      stopifnot(abs(s$att-z$score$att)<1e-10)
    }
    answer[[length(answer)+1L]] <- data.frame(
      outcome=ref$locpol$ynames[i],arm=arm,ATT=s$att,
      iid_se=s$se,cluster_se=clustered_se(s$influence))
  }
}
answer <- do.call(rbind,answer)
print(answer,row.names=FALSE,digits=7)
if(refit) write.csv(answer,file.path(destination,'comparison.csv'),row.names=FALSE)
if(!refit) {
  original <- read.csv('results/comparison.csv')
  original <- original[original$arm %in% c('paper','fixed_epanechnikov','fixed_gaussian'),]
  stopifnot(max(abs(as.matrix(answer[,3:5])-as.matrix(original[,c('ATT','iid_se','cluster_se')])))<1e-10)
  cat('EXAMPLE_RECEIPTS_PASS: all 12 ATT and uncertainty rows reproduced.\n')
}
