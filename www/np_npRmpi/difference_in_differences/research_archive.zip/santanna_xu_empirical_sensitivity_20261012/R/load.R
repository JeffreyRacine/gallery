# Reuse the exact private installation, or install the retained tarballs here.
private<-if(dir.exists('reproduction_artifacts/Rlib/np'))'reproduction_artifacts/Rlib' else
 '../santanna_xu_published_comparison_20261012/reproduction_artifacts/Rlib'
stopifnot(dir.exists(file.path(private,'np')),dir.exists(file.path(private,'compdid')))
.libPaths(c(normalizePath(private),.libPaths()))
suppressPackageStartupMessages(library(np))
suppressPackageStartupMessages(library(compdid))
stopifnot(as.character(packageVersion('np'))=='0.80.1',as.character(packageVersion('compdid'))=='0.1.0')
options(np.messages=FALSE)
source('R/data.R')
