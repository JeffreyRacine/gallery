source('R/load.R')
fit_fixed_application<-function(i,kernel) {
 stopifnot(i %in% 1:4,kernel %in% c('epanechnikov','gaussian'))
 x<-make_x(i);y<-dat[[ref$locpol$ynames[i]]];ps<-ref$locpol$ps_fit[[i]]$fitted.values
 a<-new.env(parent=emptyenv());a$stage<-'start';a$warnings<-character();a$outcomes<-vector('list',4)
 a$mu<-matrix(NA_real_,nrow(dat),4);a$mu[,1]<-0
 started<-proc.time()[['elapsed']]
 ans<-tryCatch(withCallingHandlers({
   for(g in 2:4) {
     a$stage<-paste0('bandwidth_cell_',g);message(a$stage)
     tr<-which(cells[,g]==1);te<-which(cells[,1]==1)
     seed<-NA_integer_;published_bw<-as.numeric(ref$locpol$or_fit[[i]]$bws)
     bandwidths<-c(rep(published_bw[1]/sqrt(5),2),rep(published_bw[2],9))
     b<-npregbw(xdat=x[tr,,drop=FALSE],ydat=y[tr],bws=bandwidths,bandwidth.compute=FALSE,
       regtype='ll',ckertype=kernel,ukertype='liracine')
     a$outcomes[[g]]<-list(bw=b,seed=seed,training=tr,evaluation=te)
     a$stage<-paste0('external_cell_',g);message(a$stage)
     external<-as.numeric(fitted(npreg(bws=b,txdat=x[tr,,drop=FALSE],tydat=y[tr],exdat=x[te,,drop=FALSE],se=FALSE)))
     a$outcomes[[g]]$external<-external;a$mu[te,g]<-external
     a$stage<-paste0('loo_cell_',g);message(a$stage)
     loo<-as.numeric(npreghat(bws=b,txdat=x[tr,,drop=FALSE],y=y[tr],leave.one.out=TRUE,output='apply'))
     a$outcomes[[g]]$loo<-loo;a$mu[tr,g]<-loo
   }
   a$stage<-'score'
   sx_score(y,d,post,ps,a$mu)
 },warning=function(w)a$warnings<-c(a$warnings,conditionMessage(w))),error=identity)
 list(bandwidth_mode='published_variance_matched',outcome_index=i,outcome=ref$locpol$ynames[i],kernel=kernel,ok=!inherits(ans,'error'),
      error=if(inherits(ans,'error'))conditionMessage(ans) else '',score=if(!inherits(ans,'error'))ans else NULL,
      audit=as.list(a),ps=ps,x=x,y=y,d=d,post=post,cluster=cluster,row_ids=rownames(dat),
      elapsed=proc.time()[['elapsed']]-started,host=Sys.info()[['nodename']],session=sessionInfo(),
      np_library=find.package('np'),compdid_library=find.package('compdid'))
}
