# Load after R/core.R. Version 2 changes only evaluations required by the ATT
# score, not folds, tuning, local fits, optimization tolerances or bandwidths.
# Preserve R/core.R and every version-1 receipt as the original frozen record.
sx_score <- function(y, d, post, ps, mu) {
  C <- sx_cells(d, post); signs <- c(1,-1,-1,1); n <- length(y)
  stopifnot(all(dim(ps)==c(n,4)),all(dim(mu)==c(n,4)),
            all(is.finite(c(y,d,post))),all(C %in% 0:1),
            all(rowSums(C)==1),all(colSums(C)>0))
  raw <- matrix(0,n,4); raw[,1] <- C[,1]
  required_ps <- numeric()
  for(g in 2:4) {
    used <- C[,g]==1
    needed <- ps[used,c(1,g),drop=FALSE]
    if(any(!is.finite(needed)) || any(needed<=0))
      stop('Required propensity prediction is undefined or nonpositive')
    raw[used,g] <- ps[used,1]/ps[used,g]
    required_ps <- c(required_ps,needed)
  }
  w <- sweep(raw,2,colMeans(raw),'/')
  summand <- w[,1]*y
  for(g in 2:4) {
    used <- C[,1]==1 | C[,g]==1
    if(any(!is.finite(mu[used,g])))
      stop('Required outcome prediction is undefined')
    summand <- summand+signs[g]*w[,g]*y
    summand[used] <- summand[used]+signs[g]*(w[used,1]-w[used,g])*mu[used,g]
  }
  att <- mean(summand); influence <- summand-w[,1]*att
  se <- sd(influence)/sqrt(n)
  list(att=att,se=se,lower=att-qnorm(.975)*se,upper=att+qnorm(.975)*se,
       influence=influence,weights=w,ess=colSums(w)^2/colSums(w^2),
       minimum_ps=min(ps[is.finite(ps)]),maximum_weight=max(w),
       minimum_required_ps=min(required_ps))
}

sx_crossfit <- function(dat,K=2L,seed=20261012L,verbose=TRUE) {
  n <- length(dat$y); C <- sx_cells(dat$d,dat$post)
  fold <- sx_folds(n,K,seed)
  ps <- mu <- matrix(NA_real_,n,4); tuning <- vector('list',K)
  for(k in seq_len(K)) {
    if(verbose) message('Cross-fitting fold ',k,'/',K)
    tr <- which(fold!=k); te <- which(fold==k)
    if(any(colSums(C[tr,,drop=FALSE])<5)) stop('Insufficient cell observations in training fold')
    b <- sx_ps_bw(dat$x[tr,,drop=FALSE],C[tr,,drop=FALSE])
    p <- sx_ps(dat$x[tr,,drop=FALSE],C[tr,,drop=FALSE],dat$x[te,,drop=FALSE],b$h,b$lambda)
    if(any(p$status!=0 & C[te,1]!=1))
      stop('Required held-out propensity fit failed; no fallback used')
    ps[te,] <- p$probability
    ps[te[p$status!=0],] <- NA_real_
    bandwidths <- list(); mu[te,1] <- 0
    for(g in 2:4) {
      rows <- tr[C[tr,g]==1]
      bw <- np::npregbw(xdat=dat$x[rows,,drop=FALSE],ydat=dat$y[rows],
        regtype='ll',ckertype='epanechnikov',ukertype='liracine',
        bwmethod='cv.ls',nmulti=2)
      fit <- np::npreg(bws=bw,txdat=dat$x[rows,,drop=FALSE],tydat=dat$y[rows],
                      exdat=dat$x[te,,drop=FALSE],se=FALSE)
      mu[te,g] <- as.numeric(fitted(fit)); bandwidths[[g]] <- bw
    }
    tuning[[k]] <- list(ps=b,or=bandwidths,training=tr,evaluation=te,
      ps_max_gradient=max(p$gradient),ps_status=p$status)
  }
  good_ps <- rowSums(is.finite(ps))==4L
  stopifnot(max(abs(rowSums(ps[good_ps,,drop=FALSE])-1))<1e-12)
  list(score=sx_score(dat$y,dat$d,dat$post,ps,mu),ps=ps,mu=mu,
       folds=fold,tuning=tuning,implementation='score-aware-v2')
}
