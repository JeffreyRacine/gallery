# Controlled kernel-shape comparison, declared before fitting

The original eight retuned jobs are complete and retained unchanged. Epanechnikov
returned two invalid-objective search errors and two undefined-prediction errors.
Gaussian completed, but the bribe-probability ATT is -4.756 and log-bribe ATT is
+2.396. The original exercise permits 11 bandwidths in each of three cells;
it changes substantially more than the kernel relative to the paper's two
shared bandwidths. It does not establish a stable default for this application.

To answer Jeffrey's replication-first sensitivity question, add exactly eight
fixed-bandwidth calculations: both continuous kernels for four outcomes. Use
only the outcome bandwidths already archived with the published results, before
any new results are seen. Share each published h and lambda across cells, use
h/sqrt(5) for each continuous np bandwidth and lambda for each categorical one.
For np's variance-one Epanechnikov and Gaussian kernels this holds the smoothing
kernel variance fixed while varying its shape. Retain Li–Racine unordered
weighting in both arms, saved paper propensities and all other score/inference
choices. There is no CV, no seed search and no data-dependent bandwidth rescue.

These are distinct, labelled sensitivity arms. They do not replace, retry,
reclassify or erase any failed retuned result. Execute once, with at most 300
seconds for the whole fixed calculation, on pc-racine1 using the existing
private installation. Verify a focused selection of fixed predictions against
independent local weighted least squares, where local full rank permits it.
No package arithmetic or numerical policy changes are authorized or needed.

This bounded addition follows the user-requested goal of a reasonable empirical
replication with kernel sensitivity. It is not another Monte Carlo campaign.
