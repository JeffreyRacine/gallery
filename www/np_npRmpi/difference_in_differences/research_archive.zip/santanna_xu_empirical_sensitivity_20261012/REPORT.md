# Empirical reproduction and implementation comparison: completed

October 12, 2026. The bounded comparison supports a successful same-data implementation example at the published smoothing scale. The saved-fit stage is computational reproduction; fresh np outcome regressions and the independently coded ATT score constitute a same-data implementation comparison with shared archived propensities. Quantitative and qualitative comparability is its success criterion. The published DR calculations reproduce to numerical precision, and the two np kernels give similar results. Independently re-tuned outcome fits remain unstable and are prominently disclosed. See the [terminology clarification](TERMINOLOGY.md).

The [rendered example](example/empirical_example.html), [Quarto source](example/empirical_example.qmd), and [executable R example](example/empirical_example.R) contain the method, results, limitations and reproduction commands. The [plan](PLAN.md) and [pre-fit addendum](FIXED_BANDWIDTH_ADDENDUM.md) preserve the sequence of decisions.

## Main results

Composition-robust ATT, with clustered multiplier SE in parentheses; archived propensity arrays are shared and continuous smoothing variance is matched at published outcome bandwidths.

| Outcome | Paper, saved nuisances | np Epanechnikov | np Gaussian |
| --- | --- | --- | --- |
| Bribe probability | -0.3068 (0.1086) | -0.3115 (0.1105) | -0.3095 (0.1100) |
| Log(1 + bribe) | -2.8884 (0.9148) | -2.9211 (0.9192) | -2.9633 (0.9177) |
| Log(1 + bribe / shipment value) | -0.0274 (0.0145) | -0.0178 (0.0136) | -0.0179 (0.0133) |
| Log(1 + bribe / shipment tonnage) | -1.1307 (0.6346) | -1.5718 (0.6121) | -1.6226 (0.6133) |

The first two outcomes are quantitatively close to the published effects. Shipment-value and tonnage magnitudes differ materially, but the two np kernels remain close. The criterion is quantitative and qualitative comparability, not numerical equality. All four effect directions agree and kernel sensitivity is small. Normal 95% clustered intervals for tonnage exclude zero in the np arms but include zero for the published calculation, so statistical evidence for this outcome is stronger with np. This is a disclosed inferential difference within the broadly comparable substantive pattern.

## Retained re-tuned comparison

| Outcome | Re-tuned Epanechnikov | Re-tuned Gaussian ATT (SE) |
| --- | --- | --- |
| Bribe probability | Failed: invalid search objective | -4.7556 (6.3648) |
| Log(1 + bribe) | Failed: undefined required prediction | 2.3964 (1.0403) |
| Log(1 + bribe / shipment value) | Failed: undefined required prediction | -0.0119 (0.0028) |
| Log(1 + bribe / shipment tonnage) | Failed: invalid search objective | -1.9012 (0.7757) |

All eight processes exited zero and none timed out; four statistical fits succeeded and four failed. Two Epanechnikov failures have explicit zero-weight prediction warnings. The two invalid-raw-objective failures remain a separate search-failure class, without an asserted geometric root cause. Gaussian completion did not ensure stable extrapolation. No fallback, response clipping, retries, relaxed tolerance, production repair or new propensity search was introduced.

## Verification and provenance

- Both published DR rows, IID and clustered SEs, and stationarity tests reproduce at the saved nuisances. Maximum ATT/SE discrepancy: 3.1e-14.
- All eight fixed-bandwidth fits succeeded in one additional calculation, raw process exit zero. Independent author-score/influence checks differ by at most 2.2e-12. All 144 selected full-rank weighted-QR prediction checks passed, maximum difference 4.0e-13; this is a focused sample, not every prediction.
- The base-R example re-evaluates all twelve paper/fixed-kernel ATT and uncertainty rows within 1e-10. Shared propensity arrays and sample row identities are verified.
- The eight re-tuned jobs ran on M2MBP (1–4) and pc-racine1 (5–8); the fixed comparison ran on pc-racine1. Controller settings were four workers per host, nice 20, one math thread, and 1,800 seconds per re-tuned job. Jobs finished before a live worker-count observation; configured parallelism is not presented as an independently observed live count. The fixed calculation completed well below the declared 300-second administrative cap; that run did not have an enforced watchdog.
- Exact remote/local fit, failure, process and job-log hashes match (12 files on M2MBP, 20 on pc-racine1); frozen execution sources are unchanged and owned remote processes are absent at closeout. See `inputs/remote_closeout_*.json`.
- Earlier full propensity searches remain rejected with code 10. The archived categorical-kernel discrepancy and local singular-fit differences remain disclosed. Both new kernel arms use standard unordered Li–Racine weights.
- The largest cluster contains 50.7% of observations. Inference is the specified influence-function multiplier procedure, without nuisance refitting; no new finite-sample inference or causal-identification guarantee is asserted.

`results/` retains all 8 re-tuned and 8 fixed fit objects, raw exit receipts, paper reproduction, common-multiplier summaries, failures/warnings, bandwidths, prediction ranges and independent checks. `inputs/execution_sha256.json` binds the original pre-run sources; the later fixed comparison and documents are separately bound by `FINAL_SHA256.json`. Final local preservation checks are recorded in `inputs/closeout.json`.

No production package or Gallery file was edited by this work, and nothing was pushed or published. The frozen preceding study is checked separately; concurrent package/release work is recorded rather than reset. No additional numerical campaign is required to present this qualified example honestly.
