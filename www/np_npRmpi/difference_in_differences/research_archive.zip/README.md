# Frozen research evidence

These two studies are preserved verbatim against their FINAL_SHA256.json
manifests. The full-nuisance study is the source of the Gallery example.
Original host and private-library paths are historical; use the standalone
Gallery np_composition_did.R script to reproduce the main table portably.
The archive excludes installed libraries and temporary/cache directories.
Some historical reports link to earlier investigations outside this archive.
