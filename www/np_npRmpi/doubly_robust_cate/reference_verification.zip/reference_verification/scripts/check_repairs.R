args <- commandArgs(trailingOnly = TRUE)
variant <- if (length(args)) args[1] else "patched"
mode <- if (length(args) > 1) args[2] else "installed"
root <- normalizePath(".")
.libPaths(c(file.path(root, paste0("Rlib_", variant)),
            file.path(root, "Rlib_dependencies"), .libPaths()))
if (mode == "installed") {
  library(hdcate)
  generator <- getFromNamespace("HDCATE_R6Class", "hdcate")
} else {
  env <- new.env(parent = globalenv())
  env$R6Class <- R6::R6Class
  path <- if (variant == "patched") "patched/hdcate/R/hdcate_r6_class.R" else
    "original/hdcate-76b084d99aa8c5dbeaafd3680bac7dfedd3a6a54/R/hdcate_r6_class.R"
  sys.source(path, env)
  generator <- env$HDCATE_R6Class
}
cat("Validation:", variant, mode, "\n")
set.seed(20261011)
dat <- data.frame(Y = rnorm(160), D = rep(0:1, 80), X = rnorm(160))
model <- generator$new(dat, "Y", "D", "X")
model$cond_var_name <- "X"
for (bw in list("rule-of-thumb", 0.5, "plug-in")) {
  model$bw <- bw
  subset <- seq_len(100)
  value <- tryCatch(model$get_bw(phi = dat$Y[subset], use_sample_idx = subset),
                    error = function(e) conditionMessage(e))
  cat("Bandwidth", bw, ":", value, "\n")
  if (variant == "patched") {
    expected <- if (is.numeric(bw)) bw else if (bw == "rule-of-thumb")
      bw.nrd0(dat$X) * nrow(dat)^(1/5 - 2/7) else
      KernSmooth::dpill(dat$X[subset], dat$Y[subset]) * length(subset)^(1/5 - 2/7)
    stopifnot(isTRUE(all.equal(value, expected)))
  } else if (bw != "plug-in") stopifnot(is.character(value))
}

# Deterministic branch witnesses execute the actual fit/inference method bodies.
self <- new.env(parent = emptyenv())
self$use_cross_fitting <- TRUE
self$k_fold <- 2
self$folds <- list(1:2, 3:4)
self$data <- dat[1:4, ]
self$first_stage <- function(...) NULL
self$second_stage <- function(subsample_idx, ...) {
  s <- if (1 %in% subsample_idx) 1 else 3
  list(hdcate = c(0, 0), ate = 0, vate = c(0, 0),
       sigma_hat = c(s, s), eta_hat = list(valid = 1))
}
fit_body <- generator$public_methods$fit
environment(fit_body) <- list2env(list(self = self), parent = environment(fit_body))
fit_body()
expected <- if (variant == "patched") sqrt(5) else 2
stopifnot(max(abs(self$sigma_hat - expected)) < 1e-14)
cat("Cross-fold sigma:", self$sigma_hat[1], "; paper:", sqrt(5), "\n")

self$hdcate <- matrix(c(0, 0))
self$sigma_hat <- matrix(c(1, 1))
self$eta_hat_list <- list(list(valid = 1))
self$n_obs <- 1
self$h <- 1
self$d <- 1
self$folds <- NULL
self$length_grid <- 2
self$cond_var_name <- "X"
self$cond_interval <- c(0, 1)
boot_curves <- rbind(c(3, 0, 2, 0), c(-1, -10, -1, -20))
self$draw_weights <- function(...) matrix(1, 1, 4)
counter <- 0L
self$second_stage <- function(...) {
  counter <<- counter + 1L
  list(hdcate = matrix(boot_curves[, counter]))
}
infer_body <- generator$public_methods$inference
environment(infer_body) <- list2env(list(self = self), parent = environment(infer_body))
infer_body(sig_level = c(.05, .10), n_rep_boot = 4)
expected <- quantile(apply(if (variant == "patched") abs(boot_curves) else boot_curves,
                           2, max), c(.95, .90))
stopifnot(max(abs(self$i_two_side[1, 3:4] - expected)) < 1e-14,
          max(abs(self$i_two_side[1, 1:2] + expected)) < 1e-14)
cat("Two-sided radii:", self$i_two_side[1, 3:4], "; paper: 18.5, 17\n")
boot_curves[1, 2] <- NA_real_
counter <- 0L
failed <- tryCatch({infer_body(sig_level=.05, n_rep_boot=4); NULL},
                   error=function(e) conditionMessage(e))
if (variant == 'patched') {
  stopifnot(grepl('multiplier draw 2', failed), grepl('no draws discarded', failed))
  cat('Non-finite draw correctly rejected:', failed, '\n')
} else {
  stopifnot(is.null(failed), all(is.finite(self$i_two_side)))
  cat('Original code omits the non-finite draw when computing quantiles.\n')
}
cat("PASS: focused predecessor/repair witnesses; not a complete package audit.\n")
