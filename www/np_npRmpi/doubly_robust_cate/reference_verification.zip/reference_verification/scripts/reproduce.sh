#!/bin/bash
# Run from hdcate_extension. Libraries, temporary files and outputs stay here.
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"
export TMPDIR="$ROOT_DIR/tmp"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
R_BIN="${R_BIN:-/Library/Frameworks/R.framework/Resources/bin/R}"
RSCRIPT_BIN="${RSCRIPT_BIN:-/Library/Frameworks/R.framework/Resources/bin/Rscript}"
mkdir -p "$TMPDIR" Rlib_dependencies Rlib_original Rlib_patched results/standalone figures
export R_LIBS="$ROOT_DIR/Rlib_dependencies"
# Other dependencies (np, locpol, caret, R6 and hdm's dependencies) must exist.
"$R_BIN" CMD INSTALL --library=Rlib_dependencies tarballs/hdm_0.3.2.tar.gz > results/install_dependencies.log 2>&1
"$R_BIN" CMD INSTALL --library=Rlib_original tarballs/original/hdcate_0.1.0.tar.gz > results/install_original_reproduction.log 2>&1
"$R_BIN" CMD INSTALL --library=Rlib_patched tarballs/patched/hdcate_0.1.0.tar.gz > results/install_patched_reproduction.log 2>&1
for variant in original patched; do
  for mode in source installed; do
    "$RSCRIPT_BIN" --vanilla scripts/check_repairs.R "$variant" "$mode" > "results/repair_checks_${variant}_${mode}.log" 2>&1
  done
done
"$RSCRIPT_BIN" --vanilla scripts/run_comparison.R > results/comparison_exp.log 2>&1
"$RSCRIPT_BIN" --vanilla scripts/capture_standalone.R > results/standalone.log 2>&1
"$RSCRIPT_BIN" --vanilla scripts/check_standalone.R > results/standalone_parity.log 2>&1
echo 'Completed installed-reference and standalone comparisons; see results and figures.'
