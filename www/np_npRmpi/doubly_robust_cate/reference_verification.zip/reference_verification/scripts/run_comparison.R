# Installed-reference replication: authors' DGP, lasso nuisances and fixed folds.
# Positive Exp(1) multipliers: paper Assumption 4.1 and package R6 "bayes" option.
# This is explicit, not a fallback from the failed Gaussian experiment retained
# in run_comparison_gaussian_attempt01.R and diagnose_normal_multiplier.R.
root <- normalizePath(".")
.libPaths(c(file.path(root, "Rlib_patched"), file.path(root, "Rlib_dependencies"), .libPaths()))
library(hdcate)
library(np)
options(np.messages = FALSE, digits = 12)
n <- 500L; p <- 100L; K <- 5L; B <- 1999L
grid <- seq(-1, 1, by = .02)
seeds <- c(data = 20261011L, folds = 20261012L, nuisance = 20261013L, multiplier = 20261014L)
set.seed(seeds["data"])
dat <- HDCATE.get_sim_data(n_obs = n, n_var = p, n_rel_var = 4, intercept = 10)
set.seed(seeds["folds"])
folds <- split(sample.int(n), rep(seq_len(K), each = n/K))
stopifnot(identical(sort(unlist(folds, use.names = FALSE)), seq_len(n)))
h <- 1.06 * sd(dat$X2) * n^(-2/7) # Paper, p. 25: full-sample undersmoothing.
model <- HDCATE(dat, "Y", "D", paste0("X", seq_len(p), collapse = "+"))
HDCATE.set_condition_var(model, "X2", min = min(grid), max = max(grid), step = .02)
HDCATE.use_cross_fitting(model, k_fold = K, folds = folds)
HDCATE.set_bw(model, h)
set.seed(seeds["nuisance"])
cat("STAGE: fitted reference and held-out nuisance predictions\n")
HDCATE.fit(model, verbose = FALSE)
stopifnot(all(is.finite(model$hdcate)), model$h == h)
saveRDS(list(model = model, data = dat, folds = folds, h = h, seeds = seeds),
        "results/fitted_reference.rds")

# The public npreg API supplies the same unweighted Gaussian local-linear fit.
# Explicit weighted moments below implement the paper's multiplier refits;
# ordinary np SEs/plot bands implement a different uncertainty convention.
moment_fit <- function(x, y, at, h, weights = matrix(1, length(x), 1)) {
  u <- outer(at, x, function(a, x) (x - a)/h)
  w <- dnorm(u)
  s0 <- w %*% weights
  s1 <- (w * u) %*% weights
  s2 <- (w * u^2) %*% weights
  t0 <- w %*% (weights * y)
  t1 <- (w * u) %*% (weights * y)
  determinant <- s0*s2 - s1^2
  estimate <- (s2*t0 - s1*t1)/determinant
  if (any(!is.finite(estimate))) stop("Non-finite weighted local-linear fit; no draws omitted")
  list(estimate = estimate, nonpositive_determinants = sum(determinant <= 0))
}
np_folds <- matrix(NA_real_, length(grid), K)
sigma2_folds <- np_folds
scores <- vector("list", K)
propensity <- numeric(n)
checks <- list()
cat("STAGE: npreg fit and paper variance comparison\n")
for (k in seq_len(K)) {
  idx <- folds[[k]]
  eta <- model$eta_hat_list[[k]]
  pr <- as.numeric(eta$propensity)
  stopifnot(all(is.finite(pr)), all(pr > 0 & pr < 1))
  propensity[idx] <- pr
  mu1 <- as.numeric(eta$treated); mu0 <- as.numeric(eta$untreated)
  scores[[k]] <- mu1 - mu0 + dat$D[idx]*(dat$Y[idx]-mu1)/pr -
    (1-dat$D[idx])*(dat$Y[idx]-mu0)/(1-pr)
  fit <- npreg(txdat = dat$X2[idx], tydat = scores[[k]], exdat = grid,
    bws = h, regtype = "ll", ckertype = "gaussian", ckerorder = 2,
    bwtype = "fixed", bwscaling = FALSE, se = FALSE)
  np_folds[, k] <- as.numeric(fitted(fit))
  oracle <- moment_fit(dat$X2[idx], scores[[k]], grid, h)$estimate[, 1]
  ref <- model$local_reg_model_list[[k]]$beta0
  checks[[k]] <- data.frame(fold = k, np_reference = max(abs(np_folds[, k] - ref)),
                            np_moment = max(abs(np_folds[, k] - oracle)))
  w <- dnorm(outer(grid, dat$X2[idx], "-")/h)
  fhat <- rowMeans(w)/h
  deviations <- sweep(matrix(scores[[k]], length(grid), length(idx), byrow = TRUE),
                      1, np_folds[, k], "-")
  sigma2_folds[, k] <- rowMeans(deviations^2 * w^2)/(h * fhat^2)
  cat("Verified fold", k, "; np/reference error", checks[[k]]$np_reference, "\n")
}
checks <- do.call(rbind, checks)
stopifnot(max(as.matrix(checks[-1])) < 1e-8)
tau <- rowMeans(np_folds)
sigma <- sqrt(rowMeans(sigma2_folds)) # Average variances, paper p. 19.
se <- sigma/sqrt(n*h)
stopifnot(max(abs(tau - model$hdcate)) < 1e-8,
          max(abs(sigma - model$sigma_hat)) < 1e-8)

cat("STAGE: reference Exp(1) multiplier inference (", B, " draws)\n", sep = "")
set.seed(seeds["multiplier"])
model$inference(sig_level = .05, boot_method = "bayes", n_rep_boot = B)
stopifnot(all(is.finite(model$i_two_side)))
cat("STAGE: independent multiplier reconstruction\n")
set.seed(seeds["multiplier"])
weights <- t(matrix(rexp(B*n, rate = 1), nrow = B, ncol = n, byrow = TRUE))
boot <- matrix(0, length(grid), B)
nonpositive <- integer(K)
for (k in seq_len(K)) {
  fit <- moment_fit(dat$X2[folds[[k]]], scores[[k]], grid, h, weights[folds[[k]], , drop = FALSE])
  boot <- boot + fit$estimate/K
  nonpositive[k] <- fit$nonpositive_determinants
}
t_boot <- sweep(sweep(boot, 1, tau, "-"), 1, se, "/")
max_abs <- apply(abs(t_boot), 2, max)
max_signed <- apply(t_boot, 2, max)
critical <- unname(quantile(max_abs, .95))
critical_one <- unname(quantile(max_signed, .95))
bands <- cbind(tau-critical*se, tau+critical*se)
band_error <- max(abs(bands - model$i_two_side))
stopifnot(band_error < 1e-7)

# Spot-check weighted fits against locpol with the same positive Exp(1) weights.
# This tests the bootstrap arithmetic independently of matching final quantiles.
draw_checks <- do.call(rbind, lapply(seq_len(K), function(k) {
  idx <- folds[[k]]
  do.call(rbind, lapply(c(1L, 2L, B), function(b) {
    ref <- locpol::locPolSmootherC(dat$X2[idx], scores[[k]], grid, h,
      deg = 1, kernel = locpol::gaussK, weig = weights[idx, b])$beta0
    own <- moment_fit(dat$X2[idx], scores[[k]], grid, h,
                       matrix(weights[idx, b], ncol = 1))$estimate[, 1]
    data.frame(fold = k, draw = b, maximum_error = max(abs(ref-own)))
  }))
}))
stopifnot(max(draw_checks$maximum_error) < 1e-7)
stopifnot(sum(nonpositive) == 0L)
summary <- data.frame(n, p, K, B, multipliers = "Exp(1)", grid_points = length(grid), bandwidth = h,
  critical_two_sided = critical, critical_one_sided = critical_one,
  max_np_reference_error = max(checks$np_reference),
  max_sigma_error = max(abs(sigma-model$sigma_hat)), max_band_error = band_error,
  minimum_propensity = min(propensity), maximum_propensity = max(propensity),
  nonpositive_bootstrap_determinants = sum(nonpositive),
  truth_inside_entire_band_this_sample = all(10+grid >= bands[,1] & 10+grid <= bands[,2]))
print(summary)
write.csv(summary, "results/comparison_summary.csv", row.names = FALSE)
write.csv(checks, "results/point_parity.csv", row.names = FALSE)
write.csv(draw_checks, "results/multiplier_draw_parity.csv", row.names = FALSE)
curve <- data.frame(x = grid, truth = 10+grid, estimate = tau, se,
                    point_lower = tau-qnorm(.975)*se, point_upper = tau+qnorm(.975)*se,
                    simultaneous_lower = bands[,1], simultaneous_upper = bands[,2])
write.csv(curve, "results/cate_curve.csv", row.names = FALSE)
fold_id <- integer(n)
for (k in seq_len(K)) fold_id[folds[[k]]] <- k
write.csv(data.frame(row = seq_len(n), fold = fold_id),
          "results/fold_assignments.csv", row.names = FALSE)
saveRDS(list(model = model, data = dat, folds = folds, scores = scores, seeds = seeds,
  h = h, np_folds = np_folds, sigma2_folds = sigma2_folds, bootstrap = boot,
  max_abs = max_abs, max_signed = max_signed, summary = summary, curve = curve),
  "results/comparison.rds")
capture.output(sessionInfo(), file = "results/sessionInfo.txt")
cat("PASS: installed reference point estimates, paper variance and Exp(1) two-sided multiplier bands replicated.\n")
