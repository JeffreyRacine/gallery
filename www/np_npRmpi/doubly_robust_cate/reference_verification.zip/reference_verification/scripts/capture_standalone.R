# Verification harness only: explicitly capture the display-only Gallery example.
# Run from the bundle root after reproduce.sh creates the output directories.
e <- new.env(parent = globalenv())
png("results/standalone/crossfit_cate.png", width = 1400, height = 1000, res = 150)
sys.source("scripts/np_crossfit_cate.R", envir = e)
dev.off()
saveRDS(e$cate_results, "results/standalone/replication.rds")
