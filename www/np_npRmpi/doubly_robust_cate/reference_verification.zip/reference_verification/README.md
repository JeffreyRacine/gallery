# Reference verification for the doubly robust CATE example

Pinned hdcate commit: `76b084d99aa8c5dbeaafd3680bac7dfedd3a6a54`.
The original and patched copies and built tarballs are retained separately.
Only `R/hdcate_r6_class.R` is patched; see `hdcate_repairs.patch`.
The patch corrects bandwidth indexing, cross-fold variance aggregation,
two-sided critical values, and failure reporting for missing multiplier fits.
The worked comparison explicitly uses the existing Exp(1) option.

With np, hdm and the reference dependencies (locpol, caret, R6, KernSmooth)
available, run from this directory:

```sh
R_BIN="$(command -v R)" RSCRIPT_BIN="$(command -v Rscript)" bash scripts/reproduce.sh
```

This installs retained tarballs in private libraries, checks the original and
repaired source/installed methods, fits the reference and np implementations,
and checks the standalone script. The verification harness explicitly captures
its in-memory results and plot; the ordinary Gallery example creates no files. New results go to `results/` and `figures/`;
original verification receipts remain in `receipts/`. Original-code witnesses
expect the documented defective behavior. No packages are installed systemwide.

The Gaussian failure diagnosis is retained as receipts; reproducing that
pre-guard investigation is not part of this runner. The focused non-finite-draw
guard witness is included. This is numerical verification, not a coverage study
or comprehensive audit.

See the Gallery's accompanying reproducibility note for the method, seeds,
original findings and multiplier distinction. Source copyright and license
files are retained in the source trees and tarballs.
