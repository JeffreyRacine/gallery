reference <- readRDS('results/comparison.rds')
standalone <- readRDS('results/standalone/np_crossfit_cate_results/replication.rds')
stopifnot(identical(reference$data, standalone$data),
          identical(reference$folds, standalone$folds))
scores <- numeric(nrow(reference$data))
for (k in seq_along(reference$folds)) scores[reference$folds[[k]]] <- reference$scores[[k]]
checks <- data.frame(component=c('held-out scores', 'np fold curves', 'fold variances',
                                 'multiplier curves', 'final curves and intervals'),
  maximum_error=c(max(abs(scores-standalone$score)),
    max(abs(reference$np_folds-standalone$fold_curves)),
    max(abs(reference$sigma2_folds-standalone$fold_variances)),
    max(abs(reference$bootstrap-standalone$bootstrap)),
    max(abs(as.matrix(reference$curve)-as.matrix(standalone$curve)))))
stopifnot(all(checks$maximum_error < 1e-8))
write.csv(checks,'results/standalone_parity.csv',row.names=FALSE)
stopifnot(file.copy('results/standalone/np_crossfit_cate_results/crossfit_cate.png',
          'figures/crossfit_cate.png',overwrite=TRUE))
print(checks, digits=12)
cat('PASS: standalone script reproduces the reference-verified procedure.\n')
